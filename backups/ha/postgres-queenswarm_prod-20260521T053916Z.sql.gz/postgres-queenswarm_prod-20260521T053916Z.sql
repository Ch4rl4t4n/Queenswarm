--
-- PostgreSQL database dump
--

\restrict ugEhY1BEbvvcR46HapkHpAinAfTKKSyamAafHdUdun9dVBZ4zHS3bvpIam8gBsD

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg12+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_configs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.agent_configs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    system_prompt text NOT NULL,
    user_prompt_template text,
    tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    output_format character varying(50) DEFAULT 'text'::character varying NOT NULL,
    output_destination character varying(200) DEFAULT 'dashboard'::character varying NOT NULL,
    output_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    schedule_type character varying(50) DEFAULT 'on_demand'::character varying NOT NULL,
    schedule_value character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    last_run_at timestamp with time zone,
    last_run_result jsonb,
    run_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.agent_configs OWNER TO queenswarm;

--
-- Name: agent_suggestions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.agent_suggestions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid,
    sub_agent_session_id uuid,
    proposal_type character varying(48) NOT NULL,
    proposed_by_role character varying(64) NOT NULL,
    title character varying(260) NOT NULL,
    description text NOT NULL,
    proposal_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_level character varying(16) NOT NULL,
    impact_score double precision NOT NULL,
    status character varying(24) NOT NULL,
    requires_manual_approval boolean DEFAULT false NOT NULL,
    evaluation_reason character varying(800),
    reviewed_by_subject character varying(512),
    reviewed_at timestamp with time zone,
    implemented_at timestamp with time zone
);


ALTER TABLE public.agent_suggestions OWNER TO queenswarm;

--
-- Name: agent_templates; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.agent_templates (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(120) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    icon character varying(32) DEFAULT ''::character varying NOT NULL,
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    prompt_template text DEFAULT ''::text NOT NULL,
    is_default boolean DEFAULT false NOT NULL
);


ALTER TABLE public.agent_templates OWNER TO queenswarm;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.agents (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(100) NOT NULL,
    role character varying(48) NOT NULL,
    status character varying(32) DEFAULT 'idle'::character varying NOT NULL,
    swarm_id uuid,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    pollen_points double precision DEFAULT 0.0 NOT NULL,
    performance_score double precision DEFAULT 0.0 NOT NULL,
    last_synced_at timestamp with time zone,
    last_active_at timestamp with time zone
);


ALTER TABLE public.agents OWNER TO queenswarm;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.alembic_version (
    version_num character varying(128) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO queenswarm;

--
-- Name: browser_automation_actions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.browser_automation_actions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    browser_session_id uuid NOT NULL,
    action_type character varying(32) NOT NULL,
    status character varying(24) NOT NULL,
    requires_approval boolean DEFAULT false NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_summary character varying(2000),
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.browser_automation_actions OWNER TO queenswarm;

--
-- Name: browser_automation_sessions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.browser_automation_sessions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid,
    sub_agent_session_id uuid,
    created_by_subject character varying(512),
    mode character varying(16) NOT NULL,
    status character varying(24) NOT NULL,
    start_url character varying(2048),
    current_url character varying(2048),
    allowed_domains jsonb DEFAULT '[]'::jsonb NOT NULL,
    blocked_reason character varying(800),
    expires_at timestamp with time zone,
    max_actions integer NOT NULL,
    actions_used integer NOT NULL,
    pending_approval_action jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_snapshot_text text,
    last_screenshot_base64 text,
    is_headless boolean DEFAULT true NOT NULL,
    started_at timestamp with time zone,
    ended_at timestamp with time zone
);


ALTER TABLE public.browser_automation_sessions OWNER TO queenswarm;

--
-- Name: budgets; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.budgets (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    period character varying(32) NOT NULL,
    limit_usd double precision NOT NULL,
    spent_usd double precision DEFAULT 0.0 NOT NULL,
    reset_at timestamp with time zone NOT NULL
);


ALTER TABLE public.budgets OWNER TO queenswarm;

--
-- Name: connector_vault_entries; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.connector_vault_entries (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(128) NOT NULL,
    credential_kind character varying(32) NOT NULL,
    encrypted_payload text NOT NULL,
    dashboard_user_id uuid NOT NULL,
    label character varying(256),
    tenant_id uuid
);


ALTER TABLE public.connector_vault_entries OWNER TO queenswarm;

--
-- Name: cost_records; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.cost_records (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid,
    task_id uuid,
    llm_model character varying(100) NOT NULL,
    tokens_in integer DEFAULT 0 NOT NULL,
    tokens_out integer DEFAULT 0 NOT NULL,
    cost_usd double precision NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.cost_records OWNER TO queenswarm;

--
-- Name: curated_memory; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.curated_memory (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    kind character varying(32) NOT NULL,
    content_md text DEFAULT ''::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by_user_id uuid,
    char_count integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_curated_memory_char_count_max CHECK ((char_count <= 8000))
);


ALTER TABLE public.curated_memory OWNER TO queenswarm;

--
-- Name: dashboard_api_keys; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dashboard_api_keys (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    label character varying(160),
    secret_hash character varying(255) NOT NULL,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    source_name character varying(80)
);


ALTER TABLE public.dashboard_api_keys OWNER TO queenswarm;

--
-- Name: dashboard_user_tenants; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dashboard_user_tenants (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    dashboard_user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    role character varying(32) NOT NULL,
    joined_at timestamp with time zone NOT NULL
);


ALTER TABLE public.dashboard_user_tenants OWNER TO queenswarm;

--
-- Name: dashboard_users; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dashboard_users (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(160),
    totp_secret text,
    totp_verified_at timestamp with time zone,
    totp_required boolean DEFAULT true NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    timezone character varying(96),
    notification_prefs jsonb DEFAULT '{}'::jsonb,
    active_tenant_id uuid
);


ALTER TABLE public.dashboard_users OWNER TO queenswarm;

--
-- Name: dream_cycles; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dream_cycles (
    id uuid NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    status character varying(24) DEFAULT 'running'::character varying NOT NULL,
    items_processed integer DEFAULT 0 NOT NULL,
    items_deduplicated integer DEFAULT 0 NOT NULL,
    items_consolidated integer DEFAULT 0 NOT NULL,
    digest_md text DEFAULT ''::text NOT NULL,
    traceback_text text,
    tenant_id uuid,
    dream_report jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.dream_cycles OWNER TO queenswarm;

--
-- Name: dream_insights; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dream_insights (
    id uuid NOT NULL,
    cycle_id uuid NOT NULL,
    source_kind character varying(80) NOT NULL,
    source_ref character varying(255) NOT NULL,
    summary text NOT NULL,
    confidence double precision DEFAULT 0.5 NOT NULL,
    neo4j_node_id character varying(160),
    chroma_doc_id character varying(160),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.dream_insights OWNER TO queenswarm;

--
-- Name: dynamic_connectors; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dynamic_connectors (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(160) NOT NULL,
    display_name character varying(256) NOT NULL,
    base_url text,
    auth_type character varying(32) NOT NULL,
    secrets_cipher text,
    mcp_manifest jsonb,
    allowed_manager_slugs jsonb,
    is_active boolean DEFAULT false NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    builtin_kind character varying(64),
    last_tested_at timestamp with time zone,
    dashboard_user_id uuid,
    tenant_id uuid
);


ALTER TABLE public.dynamic_connectors OWNER TO queenswarm;

--
-- Name: external_outputs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_outputs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    dashboard_user_id uuid NOT NULL,
    mission_id uuid NOT NULL,
    session_id uuid,
    text_report text NOT NULL,
    voice_script text,
    output_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    simulation_outcome jsonb,
    tags character varying(128)[] DEFAULT ARRAY[]::character varying[] NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.external_outputs OWNER TO queenswarm;

--
-- Name: external_project_api_keys; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_project_api_keys (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    label character varying(160),
    secret_hash character varying(255) NOT NULL,
    permissions jsonb DEFAULT '["run"]'::jsonb NOT NULL,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    tenant_id uuid
);


ALTER TABLE public.external_project_api_keys OWNER TO queenswarm;

--
-- Name: external_project_run_audit; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_project_run_audit (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    api_key_id uuid,
    action_slug character varying(160) NOT NULL,
    ok boolean NOT NULL,
    latency_ms integer NOT NULL,
    cost_usd numeric(12,6) DEFAULT '0'::numeric NOT NULL,
    human_approval_required boolean DEFAULT false NOT NULL,
    human_approved boolean,
    payload_excerpt text DEFAULT ''''''::text NOT NULL,
    result_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.external_project_run_audit OWNER TO queenswarm;

--
-- Name: external_projects; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_projects (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(128) NOT NULL,
    display_name character varying(256) NOT NULL,
    project_kind character varying(32) NOT NULL,
    owner_dashboard_user_id uuid NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    webhook_url text,
    webhook_secret_hash character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.external_projects OWNER TO queenswarm;

--
-- Name: foragers; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.foragers (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(140) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    source_type character varying(32) DEFAULT 'rss'::character varying NOT NULL,
    source_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    filter_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    prompt_template text DEFAULT ''::text NOT NULL,
    tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    agent_template_id uuid,
    supervisor_routine_id uuid
);


ALTER TABLE public.foragers OWNER TO queenswarm;

--
-- Name: goal_audit_results; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.goal_audit_results (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    goal_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    iteration integer NOT NULL,
    is_done boolean DEFAULT false NOT NULL,
    reasoning text DEFAULT ''::text NOT NULL,
    remaining_work_md text DEFAULT ''::text NOT NULL,
    confidence double precision DEFAULT 0 NOT NULL,
    raw_payload jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.goal_audit_results OWNER TO queenswarm;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.goals (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    title character varying(240) NOT NULL,
    description_md text DEFAULT ''::text NOT NULL,
    acceptance_criteria_md text DEFAULT ''::text NOT NULL,
    max_iterations integer DEFAULT 3 NOT NULL,
    budget_usd double precision DEFAULT 0 NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    current_iteration integer DEFAULT 0 NOT NULL,
    root_task_id uuid,
    completed_at timestamp with time zone,
    halt_reason text,
    spent_usd double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public.goals OWNER TO queenswarm;

--
-- Name: hive_async_workflow_runs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.hive_async_workflow_runs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    celery_task_id character varying(96) NOT NULL,
    swarm_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    hive_task_id uuid,
    requested_by_subject character varying(512),
    lifecycle character varying(32) DEFAULT 'queued'::character varying NOT NULL,
    result_snapshot jsonb,
    error_text text,
    finished_at timestamp with time zone
);


ALTER TABLE public.hive_async_workflow_runs OWNER TO queenswarm;

--
-- Name: hive_llm_secrets; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.hive_llm_secrets (
    provider character varying(32) NOT NULL,
    ciphertext text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hive_llm_secrets OWNER TO queenswarm;

--
-- Name: hive_stripe_secrets; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.hive_stripe_secrets (
    id integer NOT NULL,
    secret_key_ciphertext text,
    webhook_secret_ciphertext text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hive_stripe_secrets OWNER TO queenswarm;

--
-- Name: hive_stripe_secrets_id_seq; Type: SEQUENCE; Schema: public; Owner: queenswarm
--

CREATE SEQUENCE public.hive_stripe_secrets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hive_stripe_secrets_id_seq OWNER TO queenswarm;

--
-- Name: hive_stripe_secrets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: queenswarm
--

ALTER SEQUENCE public.hive_stripe_secrets_id_seq OWNED BY public.hive_stripe_secrets.id;


--
-- Name: hive_vector_documents; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.hive_vector_documents (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    collection_name text NOT NULL,
    document text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    embedding public.vector(384) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hive_vector_documents OWNER TO queenswarm;

--
-- Name: imitation_events; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.imitation_events (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    copier_agent_id uuid NOT NULL,
    copied_agent_id uuid NOT NULL,
    recipe_id uuid,
    outcome character varying(50)
);


ALTER TABLE public.imitation_events OWNER TO queenswarm;

--
-- Name: knowledge_items; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.knowledge_items (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_url character varying(2048),
    source_type character varying(50) NOT NULL,
    content_text text NOT NULL,
    embedding_id character varying(160),
    neo4j_node_id character varying(160),
    confidence_score double precision DEFAULT 0.5 NOT NULL,
    topic_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    decay_factor double precision DEFAULT 1.0 NOT NULL,
    scraped_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    tenant_id uuid
);


ALTER TABLE public.knowledge_items OWNER TO queenswarm;

--
-- Name: learning_logs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.learning_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    task_id uuid,
    insight_text text NOT NULL,
    applied_at timestamp with time zone,
    pollen_earned double precision DEFAULT 0.0 NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.learning_logs OWNER TO queenswarm;

--
-- Name: memory_evolution_proposals; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.memory_evolution_proposals (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    proposal_kind character varying(48) NOT NULL,
    title character varying(240) NOT NULL,
    summary character varying(2000) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(24) NOT NULL,
    importance_score double precision NOT NULL,
    requires_manual_approval boolean DEFAULT false NOT NULL,
    proposed_by_user_id uuid,
    approved_by_user_id uuid,
    approved_at timestamp with time zone
);


ALTER TABLE public.memory_evolution_proposals OWNER TO queenswarm;

--
-- Name: operator_external_apis; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.operator_external_apis (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(80) NOT NULL,
    label character varying(160) NOT NULL,
    ciphertext text NOT NULL,
    base_url character varying(512),
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.operator_external_apis OWNER TO queenswarm;

--
-- Name: paper_trading_accounts; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.paper_trading_accounts (
    id uuid NOT NULL,
    tenant_id uuid,
    project_id uuid NOT NULL,
    cash_usd numeric(16,4) DEFAULT '10000'::numeric NOT NULL,
    starting_cash_usd numeric(16,4) DEFAULT '10000'::numeric NOT NULL,
    realized_pnl_usd numeric(16,4) DEFAULT '0'::numeric NOT NULL,
    daily_realized_pnl_usd numeric(16,4) DEFAULT '0'::numeric NOT NULL,
    daily_pnl_reset_at timestamp with time zone,
    is_halted boolean DEFAULT false NOT NULL,
    halt_reason character varying(500),
    last_tick_at timestamp with time zone,
    watchlist jsonb DEFAULT '["BTC", "ETH"]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.paper_trading_accounts OWNER TO queenswarm;

--
-- Name: paper_trading_fills; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.paper_trading_fills (
    id uuid NOT NULL,
    tenant_id uuid,
    project_id uuid NOT NULL,
    account_id uuid NOT NULL,
    symbol character varying(32) NOT NULL,
    side character varying(8) NOT NULL,
    quantity numeric(18,8) NOT NULL,
    fill_price_usd numeric(16,4) NOT NULL,
    fees_usd numeric(12,4) DEFAULT '0'::numeric NOT NULL,
    notional_usd numeric(16,4) NOT NULL,
    confidence numeric(6,4) DEFAULT '0'::numeric NOT NULL,
    signal_note text DEFAULT ''::text NOT NULL,
    verified boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.paper_trading_fills OWNER TO queenswarm;

--
-- Name: pending_review_items; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.pending_review_items (
    id uuid NOT NULL,
    task_id uuid,
    swarm_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    simulation_id uuid,
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    reason character varying(64) NOT NULL,
    confidence_fraction double precision,
    verification_passed boolean DEFAULT false NOT NULL,
    verification_notes text,
    step_summary jsonb,
    resolved_at timestamp with time zone,
    resolved_by character varying(128),
    resolution_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pending_review_items OWNER TO queenswarm;

--
-- Name: platform_feature_policies; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.platform_feature_policies (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    feature_key character varying(64) NOT NULL,
    profile_key character varying(32) NOT NULL,
    enabled boolean NOT NULL
);


ALTER TABLE public.platform_feature_policies OWNER TO queenswarm;

--
-- Name: pollen_rewards; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.pollen_rewards (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    task_id uuid,
    amount double precision NOT NULL,
    reason character varying(500) NOT NULL,
    source_agent_id uuid,
    verified_reward boolean DEFAULT false NOT NULL
);


ALTER TABLE public.pollen_rewards OWNER TO queenswarm;

--
-- Name: public_share_links; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.public_share_links (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    resource_type character varying(32) NOT NULL,
    resource_id uuid NOT NULL,
    share_token character varying(96) NOT NULL,
    created_by_user_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    expires_at timestamp with time zone,
    access_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.public_share_links OWNER TO queenswarm;

--
-- Name: recipes; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    topic_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    workflow_template jsonb NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    fail_count integer DEFAULT 0 NOT NULL,
    avg_pollen_earned double precision DEFAULT 0.0 NOT NULL,
    embedding_id character varying(160),
    created_by_agent_id uuid,
    verified_at timestamp with time zone,
    last_used_at timestamp with time zone,
    is_deprecated boolean DEFAULT false NOT NULL
);


ALTER TABLE public.recipes OWNER TO queenswarm;

--
-- Name: simulations; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.simulations (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    task_id uuid,
    scenario jsonb NOT NULL,
    result_data jsonb,
    result_type character varying(32) NOT NULL,
    confidence_pct double precision DEFAULT 0.0 NOT NULL,
    docker_container_id character varying(128),
    duration_sec double precision,
    stdout text,
    stderr text
);


ALTER TABLE public.simulations OWNER TO queenswarm;

--
-- Name: skill_marketplace_listings; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.skill_marketplace_listings (
    id uuid NOT NULL,
    publisher_tenant_id uuid NOT NULL,
    publisher_user_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    status character varying(32) DEFAULT 'pending_review'::character varying NOT NULL,
    price_eur_cents integer NOT NULL,
    platform_cut_bps integer DEFAULT 2500 NOT NULL,
    pitch text,
    curator_note text,
    reviewer_user_id uuid,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.skill_marketplace_listings OWNER TO queenswarm;

--
-- Name: skill_purchases; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.skill_purchases (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    dashboard_user_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    stripe_checkout_session_id character varying(255),
    stripe_payment_intent_id character varying(255),
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    amount_cents integer DEFAULT 0 NOT NULL,
    currency character varying(8) DEFAULT 'eur'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    marketplace_listing_id uuid,
    platform_fee_cents integer DEFAULT 0 NOT NULL,
    publisher_tenant_id uuid
);


ALTER TABLE public.skill_purchases OWNER TO queenswarm;

--
-- Name: sub_agent_sessions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.sub_agent_sessions (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid NOT NULL,
    role character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    runtime_mode character varying(16) DEFAULT 'inprocess'::character varying NOT NULL,
    toolset jsonb DEFAULT '[]'::jsonb NOT NULL,
    short_memory jsonb DEFAULT '{}'::jsonb NOT NULL,
    spawn_order integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    last_output text,
    error_text text,
    tenant_id uuid
);


ALTER TABLE public.sub_agent_sessions OWNER TO queenswarm;

--
-- Name: sub_swarms; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.sub_swarms (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(100) NOT NULL,
    purpose character varying(32) NOT NULL,
    local_memory jsonb DEFAULT '{}'::jsonb NOT NULL,
    queen_agent_id uuid,
    last_global_sync_at timestamp with time zone,
    total_pollen double precision DEFAULT 0.0 NOT NULL,
    member_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.sub_swarms OWNER TO queenswarm;

--
-- Name: supervisor_routines; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.supervisor_routines (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(160) NOT NULL,
    goal_template text NOT NULL,
    schedule_kind character varying(16) DEFAULT 'interval'::character varying NOT NULL,
    interval_seconds integer,
    cron_expr character varying(64),
    runtime_mode character varying(16) DEFAULT 'durable'::character varying NOT NULL,
    roles jsonb DEFAULT '[]'::jsonb NOT NULL,
    retrieval_contract character varying(200),
    skills jsonb DEFAULT '[]'::jsonb NOT NULL,
    context_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(24) DEFAULT 'idle'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by_subject character varying(512),
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    last_error text,
    tenant_id uuid
);


ALTER TABLE public.supervisor_routines OWNER TO queenswarm;

--
-- Name: supervisor_session_events; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.supervisor_session_events (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid NOT NULL,
    sub_agent_session_id uuid,
    event_type character varying(64) NOT NULL,
    level character varying(16) DEFAULT 'info'::character varying NOT NULL,
    message text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.supervisor_session_events OWNER TO queenswarm;

--
-- Name: supervisor_sessions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.supervisor_sessions (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    goal text NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    runtime_mode character varying(16) DEFAULT 'inprocess'::character varying NOT NULL,
    created_by_subject character varying(512),
    context_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    swarm_id uuid,
    task_id uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_text text,
    tenant_id uuid
);


ALTER TABLE public.supervisor_sessions OWNER TO queenswarm;

--
-- Name: task_final_deliverables; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.task_final_deliverables (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    lineage_id uuid NOT NULL,
    version integer NOT NULL,
    dashboard_user_id uuid,
    source_task_id uuid,
    ballroom_session_id uuid,
    mission_id uuid,
    slug character varying(200) NOT NULL,
    title character varying(500) NOT NULL,
    markdown_body text NOT NULL,
    structured_json jsonb NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    voice_script text,
    chroma_embedding_id character varying(160),
    archive_relpath character varying(512)
);


ALTER TABLE public.task_final_deliverables OWNER TO queenswarm;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    title character varying(500) NOT NULL,
    task_type character varying(48) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    priority integer DEFAULT 5 NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb,
    agent_id uuid,
    swarm_id uuid,
    workflow_id uuid,
    parent_task_id uuid,
    pollen_awarded double precision DEFAULT 0.0 NOT NULL,
    recipe_used_id uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_msg text,
    tenant_id uuid
);


ALTER TABLE public.tasks OWNER TO queenswarm;

--
-- Name: tenant_audit_logs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenant_audit_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid,
    actor_user_id uuid,
    action character varying(64) NOT NULL,
    target_type character varying(64) NOT NULL,
    target_ref character varying(255) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.tenant_audit_logs OWNER TO queenswarm;

--
-- Name: tenant_invites; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenant_invites (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid,
    email character varying(255) NOT NULL,
    role character varying(32) NOT NULL,
    invited_by_user_id uuid NOT NULL,
    invite_token character varying(128) NOT NULL,
    status character varying(24) NOT NULL
);


ALTER TABLE public.tenant_invites OWNER TO queenswarm;

--
-- Name: tenant_subscriptions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenant_subscriptions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tier character varying(32) NOT NULL,
    status character varying(24) NOT NULL,
    stripe_customer_id character varying(128),
    stripe_subscription_id character varying(128),
    billing_cycle_anchor timestamp with time zone,
    period_end_at timestamp with time zone,
    limits_override jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_overrides jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.tenant_subscriptions OWNER TO queenswarm;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(128) NOT NULL,
    name character varying(256) NOT NULL,
    status character varying(24) NOT NULL,
    platform_mode character varying(24) DEFAULT 'internal'::character varying NOT NULL,
    operator_settings jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.tenants OWNER TO queenswarm;

--
-- Name: workflow_steps; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.workflow_steps (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    workflow_id uuid NOT NULL,
    step_order integer NOT NULL,
    description text NOT NULL,
    agent_role character varying(48) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    input_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    guardrails jsonb DEFAULT '{}'::jsonb NOT NULL,
    evaluation_criteria jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb,
    error_msg text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.workflow_steps OWNER TO queenswarm;

--
-- Name: workflows; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.workflows (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    original_task_text text NOT NULL,
    decomposition_rationale text,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    total_steps integer DEFAULT 0 NOT NULL,
    completed_steps integer DEFAULT 0 NOT NULL,
    parallelizable_groups jsonb DEFAULT '[]'::jsonb NOT NULL,
    matching_recipe_id uuid,
    estimated_duration_sec integer,
    actual_duration_sec integer
);


ALTER TABLE public.workflows OWNER TO queenswarm;

--
-- Name: hive_stripe_secrets id; Type: DEFAULT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_stripe_secrets ALTER COLUMN id SET DEFAULT nextval('public.hive_stripe_secrets_id_seq'::regclass);


--
-- Data for Name: agent_configs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.agent_configs (id, created_at, updated_at, agent_id, system_prompt, user_prompt_template, tools, output_format, output_destination, output_config, schedule_type, schedule_value, is_active, last_run_at, last_run_result, run_count) FROM stdin;
2c33ab93-6181-476c-9e60-b46ad6ae6e08	2026-05-14 18:14:18.137783+00	2026-05-14 18:14:18.137783+00	fd2e8e4a-a266-4869-93d4-34f97114094c	You coordinate hive managers and workers on queenswarm.love. Interpret user goals, delegate to the right specialists, and return concise verified outcomes.	\N	[]	text	ballroom	{"hive_tier": "orchestrator"}	on_demand	\N	t	\N	\N	0
\.


--
-- Data for Name: agent_suggestions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.agent_suggestions (id, tenant_id, created_at, updated_at, supervisor_session_id, sub_agent_session_id, proposal_type, proposed_by_role, title, description, proposal_payload, risk_level, impact_score, status, requires_manual_approval, evaluation_reason, reviewed_by_subject, reviewed_at, implemented_at) FROM stdin;
\.


--
-- Data for Name: agent_templates; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.agent_templates (id, created_at, updated_at, tenant_id, name, description, icon, category, tools, prompt_template, is_default) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.agents (id, created_at, updated_at, name, role, status, swarm_id, config, pollen_points, performance_score, last_synced_at, last_active_at) FROM stdin;
fd2e8e4a-a266-4869-93d4-34f97114094c	2026-05-14 18:14:18.137783+00	2026-05-14 18:14:18.137783+00	Orchestrator	learner	idle	\N	{"hive_tier": "orchestrator", "hive_fixed": true}	0	0	\N	\N
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.alembic_version (version_num) FROM stdin;
0045_skill_marketplace_ugc
\.


--
-- Data for Name: browser_automation_actions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.browser_automation_actions (id, tenant_id, created_at, updated_at, browser_session_id, action_type, status, requires_approval, payload, result_summary, occurred_at) FROM stdin;
\.


--
-- Data for Name: browser_automation_sessions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.browser_automation_sessions (id, tenant_id, created_at, updated_at, supervisor_session_id, sub_agent_session_id, created_by_subject, mode, status, start_url, current_url, allowed_domains, blocked_reason, expires_at, max_actions, actions_used, pending_approval_action, last_snapshot_text, last_screenshot_base64, is_headless, started_at, ended_at) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.budgets (id, created_at, updated_at, period, limit_usd, spent_usd, reset_at) FROM stdin;
\.


--
-- Data for Name: connector_vault_entries; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.connector_vault_entries (id, created_at, updated_at, slug, credential_kind, encrypted_payload, dashboard_user_id, label, tenant_id) FROM stdin;
\.


--
-- Data for Name: cost_records; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.cost_records (id, created_at, updated_at, agent_id, task_id, llm_model, tokens_in, tokens_out, cost_usd, tenant_id) FROM stdin;
90040c8b-eb8a-440e-9b0b-c8bc37465283	2026-05-14 20:35:06.209385+00	2026-05-14 20:35:06.209385+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
546d403e-b3e3-4bf5-9b59-40ea9071f55f	2026-05-14 20:53:31.365767+00	2026-05-14 20:53:31.365767+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	3791	0.019590000000000003	\N
1c69a0d2-8f98-4c13-a1ce-473739672069	2026-05-15 10:11:01.149395+00	2026-05-15 10:11:01.149395+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
5aae2187-7efb-4fe3-9b0b-9b2d6448c573	2026-05-15 10:13:28.628137+00	2026-05-15 10:13:28.628137+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
048eb8cb-0aeb-452d-8b05-bdc0389cc299	2026-05-16 21:21:38.490769+00	2026-05-16 21:21:38.490769+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
2abfb051-65b1-4bd6-a63e-ad448628f54c	2026-05-17 14:49:01.627257+00	2026-05-17 14:49:01.627257+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	3559	0.018430000000000002	\N
bac1f57c-e579-4ed7-b1a7-e5e1bd8554a2	2026-05-18 20:34:49.528744+00	2026-05-18 20:34:49.528744+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	3665	0.01896	\N
28d52c2a-7471-4a77-bbb6-a11b4ae1b979	2026-05-19 10:20:18.738291+00	2026-05-19 10:20:18.738291+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
b15344d0-37af-4a21-966f-98d6b3140c28	2026-05-19 10:21:58.719905+00	2026-05-19 10:21:58.719905+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	2859	0.01493	\N
e04f1c6c-c66a-4825-8bd2-170cb904d12a	2026-05-20 13:44:39.662325+00	2026-05-20 13:44:39.662325+00	\N	\N	xai/grok-3-mini	656	1652	0.0048156	\N
63229f23-c3b5-4fd2-9522-4996fdf2b440	2026-05-20 16:22:58.691491+00	2026-05-20 16:22:58.691491+00	\N	\N	xai/grok-3-mini	656	1399	0.0041831	\N
b0f6a8d1-adf9-499a-9103-7800ec31e655	2026-05-20 17:47:58.549414+00	2026-05-20 17:47:58.549414+00	\N	\N	xai/grok-3-mini	656	1492	0.0044156	\N
\.


--
-- Data for Name: curated_memory; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.curated_memory (id, tenant_id, kind, content_md, version, updated_at, updated_by_user_id, char_count) FROM stdin;
\.


--
-- Data for Name: dashboard_api_keys; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dashboard_api_keys (id, created_at, updated_at, user_id, label, secret_hash, last_used_at, revoked_at, source_name) FROM stdin;
\.


--
-- Data for Name: dashboard_user_tenants; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dashboard_user_tenants (id, created_at, updated_at, dashboard_user_id, tenant_id, role, joined_at) FROM stdin;
b44462cc-898e-499d-bcf4-4aab04d335cf	2026-05-16 19:54:05.488747+00	2026-05-16 19:54:05.488747+00	0c294d55-2420-4614-b014-a29895605ad2	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72	owner	2026-05-16 19:54:05.744882+00
43a05c94-e385-400d-948f-a06ee14d93a4	2026-05-16 20:29:23.440129+00	2026-05-16 20:29:23.440129+00	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	e098b808-8974-4bae-a6e1-de10bf6a2880	owner	2026-05-16 20:29:23.69613+00
\.


--
-- Data for Name: dashboard_users; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dashboard_users (id, created_at, updated_at, email, password_hash, display_name, totp_secret, totp_verified_at, totp_required, is_admin, is_active, timezone, notification_prefs, active_tenant_id) FROM stdin;
e4dc7671-80dd-4d69-af9f-27f167ee8d6d	2026-05-14 19:44:25.026822+00	2026-05-20 21:18:52.441369+00	admin@queenswarm.love	$2b$12$GdksAgGhfhA6611j9M/dSOIAj2TFKIg/oyQsW3t21XGg8EaYblFl.	Hive Queen	U37D42JQ46FX4EYKF6Z4Q5HPNKJWWDOV	2026-05-20 21:18:52.442476+00	t	t	t	\N	{"totp_backup_code_hashes": ["$2b$12$N4vNPTYOP6qYjQmSN9UkvugRX.n.N84YTQY8JhrqFlRZ1T8NMpvAe", "$2b$12$2ojETIsXq44xxCLMBKYYVueKJr5NeKcK08kIkXWNYki8gb8BVKE2G", "$2b$12$DB.KD2GrP9SSBoGkWmQLN.MyJgdRDHuf3J9HsL0.CDps4M4087OKq", "$2b$12$3LcKjHksChNeZn8RvlL.J.erf5EIBZKrJ.99OGCpESzmoP/eUMfom", "$2b$12$OG8x/KopnoHNphGbbAdLBOJoSUba.1qnbDZm/0Koq3Gfw8f0pWzSa", "$2b$12$hUHga.vPqcYmqSXnSnepiO16mCtPvi.rP6wltz0J3sZ9iLLLBFfwy", "$2b$12$XRORxZz4VahIrIMynP5dBeHsHXWSH6sAENSSGF1Wa9l8KCkaEXFq.", "$2b$12$HGrLnVg2BB46Q80OC5hqH.nx6lrvkKBv3NSN1.S6R0p6MkpA6UAlm"], "voice_provider_preferences": {"tts_tone": "professional", "latency_mode": "fast", "stt_provider": "grok", "tts_language": "en", "tts_provider": "grok", "tts_voice_id": "eve", "vad_threshold": 0.3, "silence_duration_ms": 300}}	e098b808-8974-4bae-a6e1-de10bf6a2880
0c294d55-2420-4614-b014-a29895605ad2	2026-05-16 19:54:05.384304+00	2026-05-16 19:54:05.488747+00	rbac-smoke@queenswarm.love	$2b$12$GOZYED6R.YuA/IrR1DjPZeRh1tfq/lINde.EkqNJ3JmQC8vHqDfTG	RBAC Smoke	\N	\N	f	t	t	\N	{}	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72
\.


--
-- Data for Name: dream_cycles; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dream_cycles (id, started_at, finished_at, status, items_processed, items_deduplicated, items_consolidated, digest_md, traceback_text, tenant_id, dream_report) FROM stdin;
b1bd557a-fd36-47af-b251-33ae91a7acaa	2026-05-19 03:00:00.079936+00	2026-05-19 03:00:00.716928+00	completed	0	0	0	# Nightly Dream Digest\n\n- Processed items: 0\n- Deduplicated items: 0\n- Consolidated insights: 0\n- Decayed/deleted stale insights: 0\n\n## Top Insights\nNo repetitive signals found in this window.	\N	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72	{"summary": "Learned 0 successful patterns, detected 0 repeated issues, and consolidated 0 insights.", "generated_at": "2026-05-19T03:00:00.708359+00:00", "repeated_errors": [], "success_strategies": [], "improvement_proposals": []}
a4ba639a-ad11-4133-9f08-79d223628e15	2026-05-19 03:00:00.077289+00	2026-05-19 03:00:00.719311+00	completed	0	0	0	# Nightly Dream Digest\n\n- Processed items: 0\n- Deduplicated items: 0\n- Consolidated insights: 0\n- Decayed/deleted stale insights: 0\n\n## Top Insights\nNo repetitive signals found in this window.	\N	e098b808-8974-4bae-a6e1-de10bf6a2880	{"summary": "Learned 0 successful patterns, detected 0 repeated issues, and consolidated 0 insights.", "generated_at": "2026-05-19T03:00:00.708803+00:00", "repeated_errors": [], "success_strategies": [], "improvement_proposals": []}
5265540d-4d8a-42fa-9db6-4e4e7b04c897	2026-05-20 03:00:00.101336+00	2026-05-20 03:00:00.193434+00	completed	0	0	0	# Nightly Dream Digest\n\n- Processed items: 0\n- Deduplicated items: 0\n- Consolidated insights: 0\n- Decayed/deleted stale insights: 0\n\n## Top Insights\nNo repetitive signals found in this window.	\N	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72	{"summary": "Learned 0 successful patterns, detected 0 repeated issues, and consolidated 0 insights.", "generated_at": "2026-05-20T03:00:00.187654+00:00", "repeated_errors": [], "success_strategies": [], "improvement_proposals": []}
a9856327-ac94-476a-bf37-94ea7b989e43	2026-05-20 03:00:00.103447+00	2026-05-20 03:00:00.195097+00	completed	0	0	0	# Nightly Dream Digest\n\n- Processed items: 0\n- Deduplicated items: 0\n- Consolidated insights: 0\n- Decayed/deleted stale insights: 0\n\n## Top Insights\nNo repetitive signals found in this window.	\N	e098b808-8974-4bae-a6e1-de10bf6a2880	{"summary": "Learned 0 successful patterns, detected 0 repeated issues, and consolidated 0 insights.", "generated_at": "2026-05-20T03:00:00.189057+00:00", "repeated_errors": [], "success_strategies": [], "improvement_proposals": []}
4d30b1ae-1c1e-47f9-9518-2b4d18e2c3ba	2026-05-21 03:00:00.093865+00	2026-05-21 03:00:00.843083+00	completed	0	0	0	# Nightly Dream Digest\n\n- Processed items: 0\n- Deduplicated items: 0\n- Consolidated insights: 0\n- Decayed/deleted stale insights: 0\n\n## Top Insights\nNo repetitive signals found in this window.	\N	e098b808-8974-4bae-a6e1-de10bf6a2880	{"summary": "Learned 0 successful patterns, detected 0 repeated issues, and consolidated 0 insights.", "generated_at": "2026-05-21T03:00:00.829983+00:00", "repeated_errors": [], "success_strategies": [], "improvement_proposals": []}
9cbcba1d-eaff-403c-bc0d-050559b52380	2026-05-21 03:00:00.09312+00	2026-05-21 03:00:00.843137+00	completed	0	0	0	# Nightly Dream Digest\n\n- Processed items: 0\n- Deduplicated items: 0\n- Consolidated insights: 0\n- Decayed/deleted stale insights: 0\n\n## Top Insights\nNo repetitive signals found in this window.	\N	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72	{"summary": "Learned 0 successful patterns, detected 0 repeated issues, and consolidated 0 insights.", "generated_at": "2026-05-21T03:00:00.832027+00:00", "repeated_errors": [], "success_strategies": [], "improvement_proposals": []}
\.


--
-- Data for Name: dream_insights; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dream_insights (id, cycle_id, source_kind, source_ref, summary, confidence, neo4j_node_id, chroma_doc_id, created_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: dynamic_connectors; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dynamic_connectors (id, created_at, updated_at, slug, display_name, base_url, auth_type, secrets_cipher, mcp_manifest, allowed_manager_slugs, is_active, is_builtin, builtin_kind, last_tested_at, dashboard_user_id, tenant_id) FROM stdin;
00000000-0000-4000-a000-000000000071	2026-05-14 18:14:18.137783+00	2026-05-14 18:14:18.137783+00	grokipedia	Grokipedia (built-in)	https://grokipedia.org	none	\N	{"tools": [{"name": "article_fetch", "path": "/wiki/{slug}", "method": "GET", "description": "Fetch Grokipedia article body as cleaned text (Wikipedia successor lane)."}]}	["research_intelligence"]	t	t	grokipedia	\N	\N	\N
\.


--
-- Data for Name: external_outputs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_outputs (id, created_at, dashboard_user_id, mission_id, session_id, text_report, voice_script, output_metadata, simulation_outcome, tags, tenant_id) FROM stdin;
\.


--
-- Data for Name: external_project_api_keys; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_project_api_keys (id, created_at, project_id, label, secret_hash, permissions, revoked_at, last_used_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: external_project_run_audit; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_project_run_audit (id, created_at, project_id, api_key_id, action_slug, ok, latency_ms, cost_usd, human_approval_required, human_approved, payload_excerpt, result_summary, tenant_id) FROM stdin;
\.


--
-- Data for Name: external_projects; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_projects (id, created_at, updated_at, slug, display_name, project_kind, owner_dashboard_user_id, settings, webhook_url, webhook_secret_hash, is_active, tenant_id) FROM stdin;
\.


--
-- Data for Name: foragers; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.foragers (id, created_at, updated_at, tenant_id, name, description, source_type, source_config, filter_config, prompt_template, tools, is_active, agent_template_id, supervisor_routine_id) FROM stdin;
\.


--
-- Data for Name: goal_audit_results; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.goal_audit_results (id, created_at, updated_at, goal_id, tenant_id, iteration, is_done, reasoning, remaining_work_md, confidence, raw_payload) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.goals (id, created_at, updated_at, tenant_id, user_id, title, description_md, acceptance_criteria_md, max_iterations, budget_usd, status, current_iteration, root_task_id, completed_at, halt_reason, spent_usd) FROM stdin;
\.


--
-- Data for Name: hive_async_workflow_runs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.hive_async_workflow_runs (id, created_at, updated_at, celery_task_id, swarm_id, workflow_id, hive_task_id, requested_by_subject, lifecycle, result_snapshot, error_text, finished_at) FROM stdin;
\.


--
-- Data for Name: hive_llm_secrets; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.hive_llm_secrets (provider, ciphertext, updated_at) FROM stdin;
\.


--
-- Data for Name: hive_stripe_secrets; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.hive_stripe_secrets (id, secret_key_ciphertext, webhook_secret_ciphertext, updated_at) FROM stdin;
1	gAAAAABqDODMM-C00yjdi4JYZwINMCENv25rp3s3rr8bw7BtUB4C4C3MjDdSCMWwbj7Kz0D2qNOeU54lctp9AXA1fFECcTOQtWLyqgU76PDoNoobdjgixNExKan0y-z5EvFurvkHMDB2CJZZKRa1j9ilbPYdUQeszkSmOLBazN3-DJlsNAnVeWH_X4qkQ819QUIndZ8swWxNiuyAvAMsQrJt2CtLH2Iowg==	gAAAAABqDODMDR7BiwaOdkHYbPOXWE0yrPjC2p-FIpKP9xF7-2OEWp-xyB9NQ8A9E7GoSpYB6wCpfFRTxoHZzSRZ_cGPSnRoSkz05HwxibGRUctpa79bM5jprjwF3KzW9ElSb6IhNcvh	2026-05-19 22:14:36.724403+00
\.


--
-- Data for Name: hive_vector_documents; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.hive_vector_documents (id, collection_name, document, metadata, embedding, created_at, updated_at) FROM stdin;
54105eb7-9868-486a-a20c-44ee9bf5f55b	hive_mind	[researcher] goal==== MISSION ===\n\n=== IDEAL STATE ===\n\n=== SOUL ===\n\n=== SKILLS HIERARCHY ===\n\n=== END CONTEXT ===\n\nInvestigate ai trends on youtube :: researcher processed goal: === MISSION ===\n\n=== IDEAL STATE ===\n\n=== SOUL ===\n\n=== SKILLS HIERARCHY ===\n\n=== END CONTEXT ===\n\nInvestigate ai trends on youtube and stored context for downstream agents. skills=5 retrieval_sections=3 meta_prompt_tokens=75 attempt=1	{"kind": "supervisor_step", "role": "researcher", "payload": "{\\"runtime_mode\\": \\"inprocess\\", \\"skills\\": [\\"multi-step-reasoning\\", \\"decision-frameworks\\", \\"decide\\", \\"tdd\\", \\"context\\"], \\"retrieval_contract\\": \\"customer_history+policy+last_3_tasks\\", \\"retrieval_sections\\": [\\"customer_history\\", \\"policy\\", \\"last_3_tasks\\"], \\"meta_reasoning\\": {\\"role\\": \\"researcher\\", \\"goal_excerpt\\": \\"=== MISSION ===\\\\n\\\\n=== IDEAL STATE ===\\\\n\\\\n=== SOUL ===\\\\n\\\\n=== SKILLS HIERARCHY ===\\\\n\\\\n=== END CONTEXT ===\\\\n\\\\nInvestigate ai trends on youtube\\", \\"resolved\\": true, \\"attempts\\": 1, \\"strategy_score\\": 1.0, \\"retrieval_coverage\\": 3, \\"skills_applied\\": 5, \\"issues\\": [], \\"alternative_count\\": 0, \\"recommended_shift\\": \\"maintain_strategy\\", \\"evaluated_at\\": \\"2026-05-20T15:17:51.944512+00:00\\"}}", "_qs_document": "[researcher] goal==== MISSION ===\\n\\n=== IDEAL STATE ===\\n\\n=== SOUL ===\\n\\n=== SKILLS HIERARCHY ===\\n\\n=== END CONTEXT ===\\n\\nInvestigate ai trends on youtube :: researcher processed goal: === MISSION ===\\n\\n=== IDEAL STATE ===\\n\\n=== SOUL ===\\n\\n=== SKILLS HIERARCHY ===\\n\\n=== END CONTEXT ===\\n\\nInvestigate ai trends on youtube and stored context for downstream agents. skills=5 retrieval_sections=3 meta_prompt_tokens=75 attempt=1", "sub_agent_session_id": "5c1708ff-50ac-4bf1-9265-a3f3df3e6e0b", "supervisor_session_id": "5d75072d-f12b-4ac5-8c4d-befd54a36c66"}	[0.03707346,-0.05280101,-0.09761834,-0.02717097,0.07246035,0.0177741,0.0560678,0.01464382,-0.05355455,-0.05760059,-0.05292883,-0.05352044,-0.00772609,0.03963298,0.00247386,0.02065117,-0.00860999,-0.01483801,-0.11628417,-0.10600752,0.04117173,-0.00089257,0.09335121,-0.01066212,-0.05942822,0.05717159,-0.01356559,-0.03916311,0.10733043,0.0177111,0.03701951,0.08770055,0.00419991,0.04904192,0.0243152,0.00873259,-0.05689352,0.018688,0.03831867,-0.00931275,0.01879037,-0.05628454,-0.0255089,-0.06239387,0.01669427,-0.07011164,-0.07320355,-0.06960112,0.02759617,0.04775556,-0.19425389,-0.06320266,-0.0077259,-0.00072601,-0.07240302,0.05605838,0.03421651,0.01793158,0.03538628,-0.00668558,0.01763339,-0.0895553,-0.04026916,0.01372002,0.01476436,0.01024153,-0.04564584,0.00626965,0.00140754,-0.03904335,-0.01830105,0.02027863,-0.12930015,0.00911434,0.0632471,-0.02911446,-0.03667356,-0.03268701,0.03954626,-0.03678896,0.05221131,-0.10044069,0.0419409,0.0260384,-0.01963077,-0.06610301,0.00761051,-0.05770837,0.01286742,0.02173849,-0.07561907,-0.03609706,0.07917916,0.0036466,0.00618935,0.04015854,-0.04885918,-0.09558041,0.04582556,0.0383258,-0.00584471,-0.00790768,-0.01975828,0.01334802,-0.10807776,-0.01778187,-0.00728087,0.15538868,0.00930474,0.02245531,-0.05745128,0.11880664,-0.0286189,-0.0553854,0.08776571,0.02553156,-0.03811246,0.06695839,0.03663196,0.0509345,0.05596462,0.01424604,0.02470041,0.009877,-0.02109393,-0.06627717,-0.0877707,0,0.05308896,-0.02502523,-0.0009942,0.03790582,-0.01712393,0.06098887,0.00804071,0.01418157,0.00337637,-0.0876011,0.00777843,0.04237383,-0.08500578,0.0046773,-0.02296456,-0.01848229,-0.06491695,0.07773647,-0.03024969,0.02704747,0.08579264,-0.02987682,-0.01226533,-0.00468723,0.06958467,-0.00533618,-0.0452374,-0.04807877,-0.03239452,0.02473204,-0.08386875,-0.0081032,-0.04200052,-0.0052149,0.04269317,0.0884744,-0.03768846,-0.02244164,-0.0010349,-0.00951087,-0.03408388,0.02841539,0.0465252,-0.05741489,-0.11141564,-0.05933969,0.00473704,-0.01527032,0.06958976,0.05507597,0.00473813,0.02766507,0.02551318,-0.13807945,0.05714618,0.00814011,-0.01464962,0.05002347,0.00235343,-0.04185817,0.04165004,-0.04007998,-0.03689796,0.02163091,0.04245638,0.06327564,0.04190275,0.0445714,0.12094112,0.06162323,-0.11140548,0.06510028,0.03708014,-0.04970686,-0.0819668,-0.0689077,-0.0583758,-0.04009341,-0.01760113,0.0208728,0.0231,0.00821918,-0.0455792,-0.01847207,0.0165595,-0.0437024,0.00184948,-0.06447063,-0.01757261,-0.03742512,-0.02245489,0.02435996,-0.03558058,0.06919185,-0.03985787,-0,-0.06210834,-0.01523035,0.01033906,0.03695494,0.08877216,-0.04312857,0.06781154,-0.0359094,0.02942543,0.05823379,-0.01071939,-0.09755735,-0.05891407,-0.03576606,-0.04530735,-0.0254149,-0.01340307,-0.09246767,-0.03592475,0.00930334,0.01142557,0.04042918,-0.10373998,0.03401022,0.0112977,-0.0410903,-0.00223815,0.0018273,0.05537606,0.00581984,0.0492327,-0.07584335,-0.10322786,-0.02769772,-0.04089779,0.01465663,0.03962789,-0.06009137,-0.03925352,0.0315239,0.06194229,0.06305513,-0.06670004,-0.01488062,-0.00407557,0.06037557,-0.00403053,0.05908765,-0.04472648,-0.08193622,0.0255965,0.00230054,-0.09427639,-0.06035726,-0.02279801,-0.04433144,0.03141699,0.00477476,-0.01512626,-0.06807387,0.00289804,0.00993861,-0.03985397,0.03774057,0.01006018,-0.0469104,0.05804149,0.07907864,-0.11039098,-0.07584997,0.02809355,-0.05781357,0.03061943,0.022193,0.02620458,0.03032773,-0.00315421,-0.03270041,0.03753918,-0.02965166,-0.08823688,0.00011365,-0.03204996,0.01816189,0.02518916,0.13255987,-0.00042465,0.13293245,-0.03797733,-0.01012775,0.00687242,-0.07358194,-0.07292429,0.01395217,-0.01030099,-5e-08,-0.06865527,0.02366411,-0.03746701,0.06252046,0.017953,0.05172821,-0.02608162,0.03013696,0.04067554,-0.05225797,-0.04285449,-0.03310803,-0.07298647,0.05336586,0.04280486,-0.0419705,-0.01802498,0.07072424,0.01293988,-0.02744854,0.03103602,0.02613494,0.03525323,-0.0579761,0.00134595,-0.0257202,-0.01523027,0.09398059,0.00088879,-0.01450579,-0.03803266,0.00676794,-0.00828948,-0.11132884,0.05389825,-0.01604911,0.01581776,-0.04005061,-0.07398673,0.00765775,0.04499335,-0.00479877,0.06438351,0.03706455,0.00731733,0.06546059,0.02865887,0.0073374,0.0649182,-0.02439473,-0.08432937,-0.06058387,-0.07252425,0.05223726,0.06895142,0.02431673,-0.00011408,-0.00291278,0.00121798,-0.05341147,0.10868251,0.03630981,-0.01841403,-0.02662649]	2026-05-20 15:17:51.973911+00	2026-05-20 15:17:51.973911+00
3f63d236-2f2b-4603-9b05-5e6ec33a0e03	hive_mind	[coder] goal==== MISSION ===\n\n=== IDEAL STATE ===\n\n=== SOUL ===\n\n=== SKILLS HIERARCHY ===\n\n=== END CONTEXT ===\n\nInvestigate ai trends on youtube :: coder processed goal: === MISSION ===\n\n=== IDEAL STATE ===\n\n=== SOUL ===\n\n=== SKILLS HIERARCHY ===\n\n=== END CONTEXT ===\n\nInvestigate ai trends on youtube and stored context for downstream agents. skills=5 retrieval_sections=3 meta_prompt_tokens=73 attempt=1	{"kind": "supervisor_step", "role": "coder", "payload": "{\\"runtime_mode\\": \\"inprocess\\", \\"skills\\": [\\"tool-use-orchestration\\", \\"self-review-loop\\", \\"tdd\\", \\"decide\\", \\"context\\"], \\"retrieval_contract\\": \\"customer_history+policy+last_3_tasks\\", \\"retrieval_sections\\": [\\"customer_history\\", \\"policy\\", \\"last_3_tasks\\"], \\"meta_reasoning\\": {\\"role\\": \\"coder\\", \\"goal_excerpt\\": \\"=== MISSION ===\\\\n\\\\n=== IDEAL STATE ===\\\\n\\\\n=== SOUL ===\\\\n\\\\n=== SKILLS HIERARCHY ===\\\\n\\\\n=== END CONTEXT ===\\\\n\\\\nInvestigate ai trends on youtube\\", \\"resolved\\": true, \\"attempts\\": 1, \\"strategy_score\\": 1.0, \\"retrieval_coverage\\": 3, \\"skills_applied\\": 5, \\"issues\\": [], \\"alternative_count\\": 0, \\"recommended_shift\\": \\"maintain_strategy\\", \\"evaluated_at\\": \\"2026-05-20T15:17:52.440516+00:00\\"}}", "_qs_document": "[coder] goal==== MISSION ===\\n\\n=== IDEAL STATE ===\\n\\n=== SOUL ===\\n\\n=== SKILLS HIERARCHY ===\\n\\n=== END CONTEXT ===\\n\\nInvestigate ai trends on youtube :: coder processed goal: === MISSION ===\\n\\n=== IDEAL STATE ===\\n\\n=== SOUL ===\\n\\n=== SKILLS HIERARCHY ===\\n\\n=== END CONTEXT ===\\n\\nInvestigate ai trends on youtube and stored context for downstream agents. skills=5 retrieval_sections=3 meta_prompt_tokens=73 attempt=1", "sub_agent_session_id": "3b4a09ff-9c59-4c99-86bc-73dc0a64bf40", "supervisor_session_id": "5d75072d-f12b-4ac5-8c4d-befd54a36c66"}	[-0.01417352,-0.09286476,-0.11231128,-0.06893387,0.05387151,0.01400962,0.04494024,-0.03063369,-0.07004773,-0.08092241,-0.02898283,-0.05116539,-0.01978916,-0.00727812,0.02751118,0.02569797,-0.02573683,-0.02225535,-0.11120799,-0.11080207,0.05549376,0.01002509,0.01515316,0.00814628,-0.06088836,0.0626354,-0.02684359,0.00800148,0.12486813,-0.00126886,0.076331,0.07980787,0.05066616,0.06681011,0.02195684,0.01966906,-0.08114027,-0.03810296,0.02662826,0.00980479,-0.03025417,-0.02917616,-0.03490057,-0.0725513,-0.00851897,-0.05999931,-0.07188435,-0.07272948,0.03107363,-0.00230639,-0.15151222,-0.00356362,0.00934269,-0.05244479,-0.04647551,0.03064459,0.05501853,0.00146536,0.04018667,0.01470164,0.00110426,-0.05913059,0.0156866,0.0476568,-0.01011076,0.00457475,-0.04708763,0.03806066,-0.04286036,-0.08259656,-0.0518411,0.00151803,-0.11370323,0.03495537,0.04291299,-0.02864295,-0.02794021,-0.03632131,0.053929,-0.03939503,0.01332958,-0.1072212,0.04675294,0.07399198,0.00104506,-0.03954369,0.02960318,-0.03960865,0.04886225,0.05755773,-0.08703591,-0.06726752,0.08157279,0.01815089,-6.273e-05,0.02871722,-0.05029692,-0.10192921,0.02104516,0.02636381,-0.017026,-0.04922283,-0.00592567,-0.03795412,-0.10422802,-0.00129089,0.04316791,0.1938687,0.06013003,0.03075648,-0.05315313,0.1357497,-0.00567357,-0.09628271,0.08450338,0.02060499,-0.03004715,0.05867591,0.09386424,0.05520455,0.08263472,-0.0252515,-0.02059635,-0.00145855,0.01790746,-0.0856811,-0.06075542,0,0.01984342,-0.05278756,-0.01400322,0.02629448,0.00370026,0.04241155,0.01472491,0.0337317,-0.03178782,-0.05316529,0.05545636,8.359e-05,-0.10859551,0.04290645,-0.01515602,-0.01424726,-0.07340108,0.0285708,-0.03615478,0.02189237,0.04520584,-0.03168316,-0.0166234,-0.00723196,0.04549712,0.04025378,-0.06231948,-0.06448772,-0.00582807,0.01384566,-0.04874968,-0.06148775,-0.03050453,0.01460863,0.06213246,0.07990714,-0.04601862,0.01809679,-0.05203626,0.00268485,-0.0076781,0.01033876,-0.01419199,-0.06393209,-0.03455754,-0.09012109,-0.01186751,-0.00303303,0.03037287,0.07662057,0.02455129,0.06025542,0.027661,-0.10731058,0.0657283,-0.01077239,-0.03035471,0.01200851,0.02010844,0.00081553,-0.00161732,-0.06269393,-0.01655997,0.00115817,0.07939828,0.03781551,0.07816962,-0.01490525,0.07374613,0.02789364,-0.07385174,0.05241838,0.05753498,0.00645359,-0.06993153,-0.04843159,-0.06262729,-0.0774165,-0.02211419,-0.05290168,0.00794916,0.03118969,-0.0061886,0.01942322,-0.01008924,-0.02754441,0.02058742,-0.1021165,-0.02459911,0.02300413,-0.04965951,-0.03311665,-0.04381776,0.03151776,-0.02170473,-0,-0.01865231,0.00449727,0.02176388,0.01822338,0.04190821,-0.06074546,0.09078701,-0.01938652,0.04736076,0.05608226,-0.0001576,-0.07866228,-0.05502798,-0.0385675,0.02207106,-0.02414888,-0.03283277,-0.04798885,-0.02663975,0.03984959,0.03258616,0.07490392,-0.09270508,0.02767318,-0.03354915,-0.03450548,-0.03322192,0.04704374,0.08023455,-0.01912727,0.07096632,-0.06527976,-0.07994094,-0.01952638,-0.03903247,-0.0208779,0.06066907,-0.04729159,-0.03937095,0.05207683,0.06036565,0.04147141,-0.06661511,0.00569137,0.00845167,0.03748521,-0.01323994,0.0423182,-0.03194334,-0.07340512,0.01474122,-0.00198654,-0.09081508,-0.03486173,-0.02584041,-0.03134726,0.01161628,-0.0176505,-0.01303106,-0.03764157,0.02051572,-0.02130635,-0.00203156,0.01470961,0.03089658,-0.0688502,0.02970791,0.07108266,-0.11627343,-0.07492327,0.01856625,-0.0647595,-0.00166096,0.04859319,0.01911646,0.01735038,-0.03961139,-0.03648462,0.01772643,-0.03156922,-0.0807711,-0.02923096,-0.03988563,-0.00487272,0.03562926,0.13708754,0.02192479,0.08577419,-0.03509217,-0.04120185,-0.00890425,-0.03059697,-0.01384465,0.00448234,-0.03953912,-5e-08,-0.08318468,-0.00075886,-0.06337963,0.02221663,0.00120237,0.05802263,-0.00694921,0.01443895,0.02115984,-0.03872307,0.04364097,-0.02654371,-0.06578254,0.0445724,0.07030974,-0.022486,-0.05246029,0.05130836,0.01380399,-0.02776901,0.05094739,0.04203406,0.00314744,-0.09701134,-0.05422493,-0.04517774,0.00808016,0.11673299,-0.01586193,0.00423545,0.01641368,0.06304991,0.03027177,-0.13406669,0.03535324,-0.01667214,0.00260534,-0.06218522,-0.02506113,0.00604214,0.06869212,-0.01298957,0.00050703,-0.00079617,0.03490256,0.05108885,0.04564207,-0.03516221,0.05918084,-0.05482832,-0.05474984,-0.01023847,-0.11310721,0.0736082,0.1118196,-0.00452214,-0.02477803,0.0159953,-0.00521635,0.00290302,0.04952215,0.0680433,-0.0210879,-0.04284294]	2026-05-20 15:17:52.465634+00	2026-05-20 15:17:52.465634+00
234e6dd7-ef97-422d-8d25-dcc9f7416aac	hive_mind	[critic] goal==== MISSION ===\n\n=== IDEAL STATE ===\n\n=== SOUL ===\n\n=== SKILLS HIERARCHY ===\n\n=== END CONTEXT ===\n\nInvestigate ai trends on youtube :: critic processed goal: === MISSION ===\n\n=== IDEAL STATE ===\n\n=== SOUL ===\n\n=== SKILLS HIERARCHY ===\n\n=== END CONTEXT ===\n\nInvestigate ai trends on youtube and stored context for downstream agents. skills=5 retrieval_sections=3 meta_prompt_tokens=79 attempt=1	{"kind": "supervisor_step", "role": "critic", "payload": "{\\"runtime_mode\\": \\"inprocess\\", \\"skills\\": [\\"self-review-loop\\", \\"grill-me\\", \\"tdd\\", \\"decide\\", \\"context\\"], \\"retrieval_contract\\": \\"customer_history+policy+last_3_tasks\\", \\"retrieval_sections\\": [\\"customer_history\\", \\"policy\\", \\"last_3_tasks\\"], \\"meta_reasoning\\": {\\"role\\": \\"critic\\", \\"goal_excerpt\\": \\"=== MISSION ===\\\\n\\\\n=== IDEAL STATE ===\\\\n\\\\n=== SOUL ===\\\\n\\\\n=== SKILLS HIERARCHY ===\\\\n\\\\n=== END CONTEXT ===\\\\n\\\\nInvestigate ai trends on youtube\\", \\"resolved\\": true, \\"attempts\\": 1, \\"strategy_score\\": 1.0, \\"retrieval_coverage\\": 3, \\"skills_applied\\": 5, \\"issues\\": [], \\"alternative_count\\": 0, \\"recommended_shift\\": \\"maintain_strategy\\", \\"evaluated_at\\": \\"2026-05-20T15:17:52.913138+00:00\\"}}", "_qs_document": "[critic] goal==== MISSION ===\\n\\n=== IDEAL STATE ===\\n\\n=== SOUL ===\\n\\n=== SKILLS HIERARCHY ===\\n\\n=== END CONTEXT ===\\n\\nInvestigate ai trends on youtube :: critic processed goal: === MISSION ===\\n\\n=== IDEAL STATE ===\\n\\n=== SOUL ===\\n\\n=== SKILLS HIERARCHY ===\\n\\n=== END CONTEXT ===\\n\\nInvestigate ai trends on youtube and stored context for downstream agents. skills=5 retrieval_sections=3 meta_prompt_tokens=79 attempt=1", "sub_agent_session_id": "f1908da4-599e-4bce-b9b4-38bb1cd65965", "supervisor_session_id": "5d75072d-f12b-4ac5-8c4d-befd54a36c66"}	[-0.00345244,-0.06958333,-0.11541524,-0.04046241,0.05974099,0.08780068,0.09016567,0.01091922,-0.03007172,-0.04262315,-0.06673151,-0.05529179,0.01472767,-0.00846338,0.02166711,0.03177318,0.05402263,-0.00819867,-0.09407949,-0.09912978,0.07452619,0.03228042,0.06945632,0.02831858,-0.07301325,0.06760996,-0.0411912,0.03020053,0.09521715,-0.02405809,0.02737623,0.05410418,0.00493663,0.01444011,0.00360826,0.02185917,-0.09240598,0.00668815,0.0242322,0.000234,-0.00378166,-0.01053188,-0.03633717,-0.07086573,0.04531275,-0.05303371,-0.09314967,-0.07756725,0.03795395,0.02965011,-0.14648227,-0.07550692,0.04659828,-0.04935862,-0.04620383,0.06773299,0.04876993,0.03790738,0.04913467,0.00419738,0.01865429,-0.1128537,-0.04426239,0.02799667,-0.00427736,0.01443289,-0.0573981,0.02651463,-0.01725255,-0.04144185,-0.05311416,0.01191925,-0.03733129,-0.00057832,0.06053643,-0.04526271,-0.02132993,-0.07550347,0.02549625,-0.04786111,0.02760891,-0.08493278,0.03232215,0.03508559,-0.00871137,-0.07858551,0.06655137,-0.05547953,0.04157977,0.03315087,-0.08499366,-0.05258167,0.09430464,0.0041875,0.02357082,0.05156342,-0.09459132,-0.123392,0.01913816,0.05720138,0.02940834,0.00968292,-0.02750534,0.0269884,-0.09388244,-0.02463885,-0.01181516,0.19234696,0.01473225,-0.00850301,-0.07002597,0.09956607,-0.0073948,-0.05078389,0.07521,0.00710428,-0.00873129,0.01962924,0.02289845,0.05504209,0.07630795,-0.03676939,-0.01063024,0.02212123,-0.01098823,-0.05764437,-0.05726806,0,0.03722225,-0.05896487,0.02444446,0.03736595,-0.01849525,0.07780502,0.00456458,0.00319333,-0.03653219,-0.09558436,0.03155746,0.03186124,-0.10651628,0.05832849,-0.01823579,-0.05204631,-0.05387073,0.07342279,0.00054046,-0.01367787,0.06600636,0.0142038,-0.01896666,-0.03748688,0.04940621,-0.01248722,-0.0494188,-0.03762752,-0.0525711,0.02731528,-0.07123428,-0.042164,-0.05189323,0.03547058,0.03881075,0.06438071,-0.05817351,-0.00094753,0.01195036,-0.04053261,-0.01977862,0.0154242,0.00285391,-0.03782355,-0.11075262,-0.07064304,-0.01091888,-0.01397656,0.03339044,0.05350779,0.0050447,0.04954938,0.03618202,-0.11157606,0.03209824,-0.03203445,-0.02329593,0.05260677,0.00436529,-0.05104807,0.03137316,0.00715574,-0.04094994,-0.02082927,0.02766205,0.11783563,0.02568578,0.04295951,0.07317697,0.0218463,-0.14281133,0.06172737,0.03660928,-0.03287802,-0.03961323,-0.086305,-0.05962172,-0.08492959,-0.04628765,-0.01173591,-0.00944355,-0.01595613,-0.05395887,-0.01743715,-0.00217117,-0.06926424,0.02671614,-0.08884658,-0.00740331,-0.04148076,-0.09082288,0.03418831,-0.02165031,0.11176814,-0.00481815,-0,-0.05867309,-0.00525049,0.01642362,0.04998202,0.0069847,-0.04527964,0.01918385,-0.03816171,0.03862854,0.06318208,-0.03873478,-0.07474797,-0.07060337,-0.02205581,-0.02610978,-0.04441951,-0.03906518,-0.07511658,-0.03103262,-0.02743374,0.04660741,0.08567823,-0.08880107,0.0215607,0.0174409,-0.03997319,0.02120121,0.01988421,0.07076752,0.02851715,0.06356038,-0.08657026,-0.07768872,-0.00542703,-0.05721215,-0.00802899,0.05658735,-0.05336065,-0.07297491,0.04648605,0.05060594,0.03161453,-0.03729342,-0.02789586,-0.0120793,0.04467065,0.00228142,0.04636454,-0.04292493,-0.06359757,0.01321388,-0.01983813,-0.09918446,-0.03074708,-0.04559553,-0.08392138,0.0084678,0.00389169,0.01901158,-0.09123288,-0.01425129,0.02674656,-0.05719764,0.01328263,0.04018243,-0.03346173,0.05771963,0.06028083,-0.03633263,-0.04434478,0.00275779,0.00026156,0.01703274,0.04196547,0.04849246,0.04269305,-0.01509384,0.0055886,0.01072931,-0.02422145,-0.06189962,-0.00691765,0.00814003,0.0028784,0.03960114,0.1353988,0.00042064,0.14948611,-0.0174394,0.00893863,0.02981124,-0.05540824,-0.00181473,-0.00122972,-0.01941887,-5e-08,-0.09228933,-0.00508814,0.00589131,0.08506593,0.0074932,0.02338407,0.02311937,-0.02052428,0.0321657,-0.04348241,0.01555564,0.00224813,-0.04022285,-0.00837886,0.01917584,-0.03545149,-0.02911255,0.09142796,0.02612297,-0.02356581,0.0361715,-0.01412706,0.01971494,-0.05756088,0.00290161,-0.0618171,0.0024824,0.05815375,-0.03570136,0.00216059,0.00692122,0.01796019,-0.03193364,-0.12936129,0.03494547,0.0482036,0.02223222,-0.03534775,-0.05048038,-0.01669474,0.00804356,-0.00141007,0.02340075,0.01056414,0.00753148,0.04951259,0.02597475,-0.01143138,0.04168221,-0.06914925,-0.05097568,-0.03026536,-0.07610039,0.08948881,0.07851929,0.01250663,-0.03161943,-0.02824789,-0.02827711,-0.01046982,0.07240132,0.05874742,-0.00134334,-0.04598214]	2026-05-20 15:17:52.936098+00	2026-05-20 15:17:52.936098+00
\.


--
-- Data for Name: imitation_events; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.imitation_events (id, created_at, updated_at, copier_agent_id, copied_agent_id, recipe_id, outcome) FROM stdin;
\.


--
-- Data for Name: knowledge_items; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.knowledge_items (id, created_at, updated_at, source_url, source_type, content_text, embedding_id, neo4j_node_id, confidence_score, topic_tags, decay_factor, scraped_at, verified_at, tenant_id) FROM stdin;
90e40a2d-4de1-4d81-a6ab-dc9e9459ad87	2026-05-19 03:00:00.16215+00	2026-05-19 03:00:00.16215+00	dream://tenant/ab5f468c-befb-4ce5-8dc1-b81e2dda4b72/cycle/b1bd557a-fd36-47af-b251-33ae91a7acaa	dream_report	Dream cycle b1bd557a-fd36-47af-b251-33ae91a7acaa\nTenant: ab5f468c-befb-4ce5-8dc1-b81e2dda4b72\nProcessed=0 Deduplicated=0 Consolidated=0\nSuccess strategies: \nRepeated errors: \nTop insights:	\N	\N	0.82	["dreaming", "memory-consolidation", "lessons-learned"]	1	2026-05-19 03:00:00.716379+00	\N	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72
93530a12-796a-44ce-a064-2a1a94ce3d36	2026-05-19 03:00:00.136045+00	2026-05-19 03:00:00.136045+00	dream://tenant/e098b808-8974-4bae-a6e1-de10bf6a2880/cycle/a4ba639a-ad11-4133-9f08-79d223628e15	dream_report	Dream cycle a4ba639a-ad11-4133-9f08-79d223628e15\nTenant: e098b808-8974-4bae-a6e1-de10bf6a2880\nProcessed=0 Deduplicated=0 Consolidated=0\nSuccess strategies: \nRepeated errors: \nTop insights:	\N	\N	0.82	["dreaming", "memory-consolidation", "lessons-learned"]	1	2026-05-19 03:00:00.718392+00	\N	e098b808-8974-4bae-a6e1-de10bf6a2880
3610178b-0e26-4518-8dc5-d5d394bb4b9d	2026-05-20 03:00:00.147341+00	2026-05-20 03:00:00.147341+00	dream://tenant/ab5f468c-befb-4ce5-8dc1-b81e2dda4b72/cycle/5265540d-4d8a-42fa-9db6-4e4e7b04c897	dream_report	Dream cycle 5265540d-4d8a-42fa-9db6-4e4e7b04c897\nTenant: ab5f468c-befb-4ce5-8dc1-b81e2dda4b72\nProcessed=0 Deduplicated=0 Consolidated=0\nSuccess strategies: \nRepeated errors: \nTop insights:	\N	\N	0.82	["dreaming", "memory-consolidation", "lessons-learned"]	1	2026-05-20 03:00:00.192858+00	\N	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72
ef3eb587-5594-4614-89f3-d9bd89b72ca0	2026-05-20 03:00:00.150713+00	2026-05-20 03:00:00.150713+00	dream://tenant/e098b808-8974-4bae-a6e1-de10bf6a2880/cycle/a9856327-ac94-476a-bf37-94ea7b989e43	dream_report	Dream cycle a9856327-ac94-476a-bf37-94ea7b989e43\nTenant: e098b808-8974-4bae-a6e1-de10bf6a2880\nProcessed=0 Deduplicated=0 Consolidated=0\nSuccess strategies: \nRepeated errors: \nTop insights:	\N	\N	0.82	["dreaming", "memory-consolidation", "lessons-learned"]	1	2026-05-20 03:00:00.19455+00	\N	e098b808-8974-4bae-a6e1-de10bf6a2880
6464c1ba-9ed3-4bd9-a0f9-ca1cb1d708cd	2026-05-21 03:00:00.145347+00	2026-05-21 03:00:00.145347+00	dream://tenant/e098b808-8974-4bae-a6e1-de10bf6a2880/cycle/4d30b1ae-1c1e-47f9-9518-2b4d18e2c3ba	dream_report	Dream cycle 4d30b1ae-1c1e-47f9-9518-2b4d18e2c3ba\nTenant: e098b808-8974-4bae-a6e1-de10bf6a2880\nProcessed=0 Deduplicated=0 Consolidated=0\nSuccess strategies: \nRepeated errors: \nTop insights:	\N	\N	0.82	["dreaming", "memory-consolidation", "lessons-learned"]	1	2026-05-21 03:00:00.842113+00	\N	e098b808-8974-4bae-a6e1-de10bf6a2880
6258b47e-f083-4f55-8f13-ce3a28ed2e35	2026-05-21 03:00:00.156458+00	2026-05-21 03:00:00.156458+00	dream://tenant/ab5f468c-befb-4ce5-8dc1-b81e2dda4b72/cycle/9cbcba1d-eaff-403c-bc0d-050559b52380	dream_report	Dream cycle 9cbcba1d-eaff-403c-bc0d-050559b52380\nTenant: ab5f468c-befb-4ce5-8dc1-b81e2dda4b72\nProcessed=0 Deduplicated=0 Consolidated=0\nSuccess strategies: \nRepeated errors: \nTop insights:	\N	\N	0.82	["dreaming", "memory-consolidation", "lessons-learned"]	1	2026-05-21 03:00:00.842264+00	\N	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72
\.


--
-- Data for Name: learning_logs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.learning_logs (id, created_at, updated_at, agent_id, task_id, insight_text, applied_at, pollen_earned, tenant_id) FROM stdin;
\.


--
-- Data for Name: memory_evolution_proposals; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.memory_evolution_proposals (id, tenant_id, created_at, updated_at, proposal_kind, title, summary, payload, status, importance_score, requires_manual_approval, proposed_by_user_id, approved_by_user_id, approved_at) FROM stdin;
\.


--
-- Data for Name: operator_external_apis; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.operator_external_apis (id, created_at, updated_at, user_id, provider, label, ciphertext, base_url, is_active) FROM stdin;
\.


--
-- Data for Name: paper_trading_accounts; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.paper_trading_accounts (id, tenant_id, project_id, cash_usd, starting_cash_usd, realized_pnl_usd, daily_realized_pnl_usd, daily_pnl_reset_at, is_halted, halt_reason, last_tick_at, watchlist, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: paper_trading_fills; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.paper_trading_fills (id, tenant_id, project_id, account_id, symbol, side, quantity, fill_price_usd, fees_usd, notional_usd, confidence, signal_note, verified, created_at) FROM stdin;
\.


--
-- Data for Name: pending_review_items; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.pending_review_items (id, task_id, swarm_id, workflow_id, simulation_id, status, reason, confidence_fraction, verification_passed, verification_notes, step_summary, resolved_at, resolved_by, resolution_note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_feature_policies; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.platform_feature_policies (id, created_at, updated_at, feature_key, profile_key, enabled) FROM stdin;
\.


--
-- Data for Name: pollen_rewards; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.pollen_rewards (id, created_at, updated_at, agent_id, task_id, amount, reason, source_agent_id, verified_reward) FROM stdin;
\.


--
-- Data for Name: public_share_links; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.public_share_links (id, tenant_id, created_at, updated_at, resource_type, resource_id, share_token, created_by_user_id, is_active, expires_at, access_count) FROM stdin;
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.recipes (id, created_at, updated_at, name, description, topic_tags, workflow_template, success_count, fail_count, avg_pollen_earned, embedding_id, created_by_agent_id, verified_at, last_used_at, is_deprecated) FROM stdin;
1e3a54d3-150f-47df-8f98-f3940e307d20	2026-05-19 22:24:02.255217+00	2026-05-19 22:24:02.255217+00	Premium — Crypto Sentiment Swarm	Verified 4-step swarm: scrape YouTube crypto sentiment, evaluate claims, simulate portfolio paths, export trading memo. Simulation-gated export bundle.	["premium", "crypto", "trading", "simulation"]	{"steps": [{"order": 1, "agent_role": "scraper", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Scrape YouTube crypto channels for sentiment snippets", "input_schema": {"sources": "list[str]", "window_hours": "int"}, "output_schema": {"clips": "list[{title, url, sentiment_score}]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 2, "agent_role": "evaluator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Evaluate scraped claims against exchange reference feeds", "input_schema": {"clips": "list"}, "output_schema": {"verified_events": "list[dict]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 3, "agent_role": "simulator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Simulate buy/hold/sell windows with sandboxed portfolio math", "input_schema": {"portfolio": "dict", "horizon_days": "int"}, "output_schema": {"paths": "list[dict]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 4, "agent_role": "reporter", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Generate trading analysis memo for hive operators", "input_schema": {"paths": "list"}, "output_schema": {"report_md": "str"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}], "seed_key": "CRYPTO_ACKIE"}	12	2	48	\N	\N	2026-05-19 22:24:04.576713+00	2026-05-19 22:24:04.576713+00	f
df8f10bd-1b9c-458c-bf07-b00d61b2a27a	2026-05-19 22:24:02.255217+00	2026-05-19 22:24:02.255217+00	Premium — Blog Launch Pipeline	Research clusters → outline → draft → publish checklist. Battle-tested content workflow exported as Cursor/Claude SKILL.md + HIVE.md.	["premium-29", "content", "blog", "seo"]	{"steps": [{"order": 1, "agent_role": "scraper", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Scrape authoritative blogs for topic clusters", "input_schema": {"topic": "str"}, "output_schema": {"sources": "list[dict]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 2, "agent_role": "evaluator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Evaluate factual alignment of sources before drafting", "input_schema": {"sources": "list"}, "output_schema": {"fact_sheet": "dict"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 3, "agent_role": "simulator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Simulate reader engagement for alternate headlines", "input_schema": {"drafts": "list[str]"}, "output_schema": {"score": "float", "winner": "str"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 4, "agent_role": "blog_writer", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Compose markdown post and queue CMS publish", "input_schema": {"headline": "str", "fact_sheet": "dict"}, "output_schema": {"body_md": "str"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}], "seed_key": "BLOG_POST"}	9	1	36	\N	\N	2026-05-19 22:24:04.576713+00	2026-05-19 22:24:04.576713+00	f
4262f623-0d4b-4540-bb40-59d4d2ee9f59	2026-05-19 22:24:02.255217+00	2026-05-19 22:24:02.255217+00	Premium — Newsletter Growth Loop	Audience scrape, CAN-SPAM compliance pass, subject-line simulation. One-time unlock for verified newsletter automation recipe.	["premium-9", "newsletter", "email", "growth"]	{"steps": [{"order": 1, "agent_role": "scraper", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Scrape subscriber segments and recent campaign replies", "input_schema": {"segment": "str"}, "output_schema": {"signals": "list[dict]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 2, "agent_role": "evaluator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Evaluate copy for CAN-SPAM facts and disclosures", "input_schema": {"draft_html": "str"}, "output_schema": {"issues": "list[str]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 3, "agent_role": "simulator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Simulate open-rate impact for subject line variants", "input_schema": {"subjects": "list[str]"}, "output_schema": {"winner": "str"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}], "seed_key": "NEWSLETTER"}	7	0	22	\N	\N	2026-05-19 22:24:04.576713+00	2026-05-19 22:24:04.576713+00	f
9e11ce63-d797-4f40-bd02-9c5c4cd9864b	2026-05-20 06:51:28.083243+00	2026-05-20 06:51:28.083243+00	Product Mission — Revenue Swarm	Ballroom playbook: niche → verified workflow → skill export → publish on GitHub, Gumroad, and optional Stripe.	["factory", "product", "monetize", "publish"]	{"steps": [{"order": 1, "agent_role": "researcher", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Research niche pain, buyer persona, and price anchor (€9/€19/€29)", "input_schema": {"niche_hint": "str"}, "output_schema": {"offer_brief": "dict"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 2, "agent_role": "orchestrator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Decompose deliverable into 3–7 verified swarm workflow steps", "input_schema": {"offer_brief": "dict"}, "output_schema": {"workflow_steps": "list[dict]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 3, "agent_role": "simulator", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Run simulation audit on each step — block unverified outputs", "input_schema": {"workflow_steps": "list"}, "output_schema": {"verified": "bool", "confidence": "float"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 4, "agent_role": "coder", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Package SKILL.md bundle + README + Gumroad LISTING.md copy", "input_schema": {"workflow_steps": "list"}, "output_schema": {"export_checklist": "list[str]"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}, {"order": 5, "agent_role": "reporter", "guardrails": {"risks": ["stale data", "provider outage"], "mitigations": ["retry with backoff", "cache recent pulls"], "stop_conditions": ["empty corpus after 3 attempts"]}, "description": "Publish plan: GitHub folder, Gumroad product, optional Queenswarm premium tag", "input_schema": {"export_checklist": "list"}, "output_schema": {"launch_hooks": "list[str]", "listing_copy": "dict"}, "evaluation_criteria": {"must_satisfy": ["structured JSON outputs", "confidence logged"], "measurable_signals": {"freshness_minutes": "<= 15"}}}], "seed_key": "PRODUCT_MISSION"}	15	1	55	\N	\N	2026-05-20 06:51:30.312005+00	2026-05-20 06:51:30.312005+00	f
\.


--
-- Data for Name: simulations; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.simulations (id, created_at, updated_at, task_id, scenario, result_data, result_type, confidence_pct, docker_container_id, duration_sec, stdout, stderr) FROM stdin;
\.


--
-- Data for Name: skill_marketplace_listings; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.skill_marketplace_listings (id, publisher_tenant_id, publisher_user_id, recipe_id, status, price_eur_cents, platform_cut_bps, pitch, curator_note, reviewer_user_id, submitted_at, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: skill_purchases; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.skill_purchases (id, tenant_id, dashboard_user_id, recipe_id, stripe_checkout_session_id, stripe_payment_intent_id, status, amount_cents, currency, created_at, updated_at, completed_at, marketplace_listing_id, platform_fee_cents, publisher_tenant_id) FROM stdin;
628baabc-6f76-4a1e-9bb5-9ad307b458a2	e098b808-8974-4bae-a6e1-de10bf6a2880	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	df8f10bd-1b9c-458c-bf07-b00d61b2a27a	cs_test_a1VsUJa0648lwSWzvTaPZCTKisZp7r3gCnHLZpzeOgxiUkZGudDSo3XAuM	\N	pending	2900	eur	2026-05-19 22:38:16.762408+00	2026-05-19 22:38:16.762408+00	\N	\N	0	\N
0bbdac3b-6fed-404c-81be-0cdb6ccf9611	e098b808-8974-4bae-a6e1-de10bf6a2880	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	4262f623-0d4b-4540-bb40-59d4d2ee9f59	cs_test_a1yB1rs77kY8X7br4HH7Ha33XnRpmP0ZaU907vk8svSBEkJl7esZCVzVrX	pi_3TZ3aVJtYinqdSYN1ZWQjNn4	completed	900	eur	2026-05-20 06:20:38.700065+00	2026-05-20 06:27:41.593228+00	2026-05-20 06:27:41.594406+00	\N	0	\N
\.


--
-- Data for Name: sub_agent_sessions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.sub_agent_sessions (id, created_at, updated_at, supervisor_session_id, role, status, runtime_mode, toolset, short_memory, spawn_order, started_at, completed_at, last_output, error_text, tenant_id) FROM stdin;
\.


--
-- Data for Name: sub_swarms; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.sub_swarms (id, created_at, updated_at, name, purpose, local_memory, queen_agent_id, last_global_sync_at, total_pollen, member_count, is_active) FROM stdin;
\.


--
-- Data for Name: supervisor_routines; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.supervisor_routines (id, created_at, updated_at, name, goal_template, schedule_kind, interval_seconds, cron_expr, runtime_mode, roles, retrieval_contract, skills, context_payload, status, is_active, created_by_subject, last_run_at, next_run_at, last_error, tenant_id) FROM stdin;
\.


--
-- Data for Name: supervisor_session_events; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.supervisor_session_events (id, created_at, updated_at, supervisor_session_id, sub_agent_session_id, event_type, level, message, payload, occurred_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: supervisor_sessions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.supervisor_sessions (id, created_at, updated_at, goal, status, runtime_mode, created_by_subject, context_summary, swarm_id, task_id, started_at, completed_at, error_text, tenant_id) FROM stdin;
\.


--
-- Data for Name: task_final_deliverables; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.task_final_deliverables (id, created_at, lineage_id, version, dashboard_user_id, source_task_id, ballroom_session_id, mission_id, slug, title, markdown_body, structured_json, tags, voice_script, chroma_embedding_id, archive_relpath) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tasks (id, created_at, updated_at, title, task_type, status, priority, payload, result, agent_id, swarm_id, workflow_id, parent_task_id, pollen_awarded, recipe_used_id, started_at, completed_at, error_msg, tenant_id) FROM stdin;
\.


--
-- Data for Name: tenant_audit_logs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenant_audit_logs (id, created_at, updated_at, tenant_id, actor_user_id, action, target_type, target_ref, payload) FROM stdin;
fc6d2e28-16be-455f-a632-d97969c0bd6e	2026-05-19 11:18:38.936632+00	2026-05-19 11:18:38.936632+00	e098b808-8974-4bae-a6e1-de10bf6a2880	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	totp_provisioned	dashboard_user	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	{}
1a705e09-5fa2-4cf6-b5ac-685a643449f5	2026-05-19 11:19:33.261855+00	2026-05-19 11:19:33.261855+00	e098b808-8974-4bae-a6e1-de10bf6a2880	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	totp_confirmed	dashboard_user	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	{"backup_codes_issued": true}
\.


--
-- Data for Name: tenant_invites; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenant_invites (id, created_at, updated_at, tenant_id, email, role, invited_by_user_id, invite_token, status) FROM stdin;
\.


--
-- Data for Name: tenant_subscriptions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenant_subscriptions (id, tenant_id, created_at, updated_at, tier, status, stripe_customer_id, stripe_subscription_id, billing_cycle_anchor, period_end_at, limits_override, feature_overrides) FROM stdin;
62872ae9-5d00-4ce3-89b7-5a495fe2bace	e098b808-8974-4bae-a6e1-de10bf6a2880	2026-05-19 22:38:16.762408+00	2026-05-19 22:38:16.762408+00	free	active	\N	\N	\N	\N	{}	{}
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenants (id, created_at, updated_at, slug, name, status, platform_mode, operator_settings) FROM stdin;
ab5f468c-befb-4ce5-8dc1-b81e2dda4b72	2026-05-16 19:54:05.488747+00	2026-05-16 19:54:05.488747+00	rbac-smoke-0c294d55	RBAC Smoke	active	internal	{}
e098b808-8974-4bae-a6e1-de10bf6a2880	2026-05-16 20:29:23.440129+00	2026-05-20 15:23:45.404113+00	hive-queen-e4dc7671	Hive Queen	active	internal	{"supervisor_audit_digest": {"enabled": false, "window_hours": 24, "extra_recipients": [], "schedule_hour_utc": 7}, "supervisor_session_playbook": {"auto_save_on_approve": false, "mark_verified_on_auto_save": true}}
\.


--
-- Data for Name: workflow_steps; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.workflow_steps (id, created_at, updated_at, workflow_id, step_order, description, agent_role, status, input_schema, output_schema, guardrails, evaluation_criteria, result, error_msg, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.workflows (id, created_at, updated_at, original_task_text, decomposition_rationale, status, total_steps, completed_steps, parallelizable_groups, matching_recipe_id, estimated_duration_sec, actual_duration_sec) FROM stdin;
\.


--
-- Name: hive_stripe_secrets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: queenswarm
--

SELECT pg_catalog.setval('public.hive_stripe_secrets_id_seq', 1, false);


--
-- Name: agent_configs agent_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT agent_configs_pkey PRIMARY KEY (id);


--
-- Name: agent_suggestions agent_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_pkey PRIMARY KEY (id);


--
-- Name: agent_templates agent_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT agent_templates_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: browser_automation_actions browser_automation_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_actions
    ADD CONSTRAINT browser_automation_actions_pkey PRIMARY KEY (id);


--
-- Name: browser_automation_sessions browser_automation_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: connector_vault_entries connector_vault_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT connector_vault_entries_pkey PRIMARY KEY (id);


--
-- Name: connector_vault_entries connector_vault_entries_slug_key; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT connector_vault_entries_slug_key UNIQUE (slug);


--
-- Name: cost_records cost_records_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT cost_records_pkey PRIMARY KEY (id);


--
-- Name: curated_memory curated_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.curated_memory
    ADD CONSTRAINT curated_memory_pkey PRIMARY KEY (id);


--
-- Name: dashboard_api_keys dashboard_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_api_keys
    ADD CONSTRAINT dashboard_api_keys_pkey PRIMARY KEY (id);


--
-- Name: dashboard_user_tenants dashboard_user_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT dashboard_user_tenants_pkey PRIMARY KEY (id);


--
-- Name: dashboard_users dashboard_users_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT dashboard_users_pkey PRIMARY KEY (id);


--
-- Name: dream_cycles dream_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dream_cycles
    ADD CONSTRAINT dream_cycles_pkey PRIMARY KEY (id);


--
-- Name: dream_insights dream_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dream_insights
    ADD CONSTRAINT dream_insights_pkey PRIMARY KEY (id);


--
-- Name: dynamic_connectors dynamic_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT dynamic_connectors_pkey PRIMARY KEY (id);


--
-- Name: external_outputs external_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_outputs
    ADD CONSTRAINT external_outputs_pkey PRIMARY KEY (id);


--
-- Name: external_project_api_keys external_project_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_api_keys
    ADD CONSTRAINT external_project_api_keys_pkey PRIMARY KEY (id);


--
-- Name: external_project_run_audit external_project_run_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT external_project_run_audit_pkey PRIMARY KEY (id);


--
-- Name: external_projects external_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT external_projects_pkey PRIMARY KEY (id);


--
-- Name: foragers foragers_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.foragers
    ADD CONSTRAINT foragers_pkey PRIMARY KEY (id);


--
-- Name: goal_audit_results goal_audit_results_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.goal_audit_results
    ADD CONSTRAINT goal_audit_results_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: hive_async_workflow_runs hive_async_workflow_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT hive_async_workflow_runs_pkey PRIMARY KEY (id);


--
-- Name: hive_llm_secrets hive_llm_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_llm_secrets
    ADD CONSTRAINT hive_llm_secrets_pkey PRIMARY KEY (provider);


--
-- Name: hive_stripe_secrets hive_stripe_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_stripe_secrets
    ADD CONSTRAINT hive_stripe_secrets_pkey PRIMARY KEY (id);


--
-- Name: hive_vector_documents hive_vector_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_vector_documents
    ADD CONSTRAINT hive_vector_documents_pkey PRIMARY KEY (id);


--
-- Name: imitation_events imitation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT imitation_events_pkey PRIMARY KEY (id);


--
-- Name: knowledge_items knowledge_items_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT knowledge_items_pkey PRIMARY KEY (id);


--
-- Name: learning_logs learning_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT learning_logs_pkey PRIMARY KEY (id);


--
-- Name: memory_evolution_proposals memory_evolution_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_pkey PRIMARY KEY (id);


--
-- Name: operator_external_apis operator_external_apis_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.operator_external_apis
    ADD CONSTRAINT operator_external_apis_pkey PRIMARY KEY (id);


--
-- Name: paper_trading_accounts paper_trading_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.paper_trading_accounts
    ADD CONSTRAINT paper_trading_accounts_pkey PRIMARY KEY (id);


--
-- Name: paper_trading_fills paper_trading_fills_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.paper_trading_fills
    ADD CONSTRAINT paper_trading_fills_pkey PRIMARY KEY (id);


--
-- Name: pending_review_items pending_review_items_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pending_review_items
    ADD CONSTRAINT pending_review_items_pkey PRIMARY KEY (id);


--
-- Name: platform_feature_policies platform_feature_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.platform_feature_policies
    ADD CONSTRAINT platform_feature_policies_pkey PRIMARY KEY (id);


--
-- Name: pollen_rewards pollen_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT pollen_rewards_pkey PRIMARY KEY (id);


--
-- Name: public_share_links public_share_links_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT public_share_links_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: simulations simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT simulations_pkey PRIMARY KEY (id);


--
-- Name: skill_marketplace_listings skill_marketplace_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_marketplace_listings
    ADD CONSTRAINT skill_marketplace_listings_pkey PRIMARY KEY (id);


--
-- Name: skill_purchases skill_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_purchases
    ADD CONSTRAINT skill_purchases_pkey PRIMARY KEY (id);


--
-- Name: sub_agent_sessions sub_agent_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_agent_sessions
    ADD CONSTRAINT sub_agent_sessions_pkey PRIMARY KEY (id);


--
-- Name: sub_swarms sub_swarms_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_swarms
    ADD CONSTRAINT sub_swarms_pkey PRIMARY KEY (id);


--
-- Name: supervisor_routines supervisor_routines_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_routines
    ADD CONSTRAINT supervisor_routines_pkey PRIMARY KEY (id);


--
-- Name: supervisor_session_events supervisor_session_events_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT supervisor_session_events_pkey PRIMARY KEY (id);


--
-- Name: supervisor_sessions supervisor_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT supervisor_sessions_pkey PRIMARY KEY (id);


--
-- Name: task_final_deliverables task_final_deliverables_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT task_final_deliverables_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenant_audit_logs tenant_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: tenant_invites tenant_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT tenant_invites_pkey PRIMARY KEY (id);


--
-- Name: tenant_subscriptions tenant_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: agent_configs uq_agent_configs_agent_id; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT uq_agent_configs_agent_id UNIQUE (agent_id);


--
-- Name: agents uq_agents_name; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT uq_agents_name UNIQUE (name);


--
-- Name: curated_memory uq_curated_memory_tenant_kind; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.curated_memory
    ADD CONSTRAINT uq_curated_memory_tenant_kind UNIQUE (tenant_id, kind);


--
-- Name: dashboard_user_tenants uq_dashboard_user_tenant_membership; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT uq_dashboard_user_tenant_membership UNIQUE (dashboard_user_id, tenant_id);


--
-- Name: dashboard_users uq_dashboard_users_email; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT uq_dashboard_users_email UNIQUE (email);


--
-- Name: task_final_deliverables uq_deliverable_lineage_version; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT uq_deliverable_lineage_version UNIQUE (lineage_id, version);


--
-- Name: dynamic_connectors uq_dynamic_connectors_slug; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT uq_dynamic_connectors_slug UNIQUE (slug);


--
-- Name: external_projects uq_external_projects_slug; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT uq_external_projects_slug UNIQUE (slug);


--
-- Name: hive_async_workflow_runs uq_hive_async_workflow_runs_celery_task_id; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT uq_hive_async_workflow_runs_celery_task_id UNIQUE (celery_task_id);


--
-- Name: operator_external_apis uq_operator_external_user_provider_label; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.operator_external_apis
    ADD CONSTRAINT uq_operator_external_user_provider_label UNIQUE (user_id, provider, label);


--
-- Name: paper_trading_accounts uq_paper_trading_accounts_project_id; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.paper_trading_accounts
    ADD CONSTRAINT uq_paper_trading_accounts_project_id UNIQUE (project_id);


--
-- Name: platform_feature_policies uq_platform_feature_policy; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.platform_feature_policies
    ADD CONSTRAINT uq_platform_feature_policy UNIQUE (feature_key, profile_key);


--
-- Name: public_share_links uq_public_share_links_share_token; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT uq_public_share_links_share_token UNIQUE (share_token);


--
-- Name: recipes uq_recipes_name; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT uq_recipes_name UNIQUE (name);


--
-- Name: skill_marketplace_listings uq_skill_marketplace_listings_recipe; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_marketplace_listings
    ADD CONSTRAINT uq_skill_marketplace_listings_recipe UNIQUE (recipe_id);


--
-- Name: skill_purchases uq_skill_purchases_tenant_recipe; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_purchases
    ADD CONSTRAINT uq_skill_purchases_tenant_recipe UNIQUE (tenant_id, recipe_id);


--
-- Name: sub_swarms uq_sub_swarms_name; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_swarms
    ADD CONSTRAINT uq_sub_swarms_name UNIQUE (name);


--
-- Name: tenant_invites uq_tenant_invites_invite_token; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT uq_tenant_invites_invite_token UNIQUE (invite_token);


--
-- Name: tenant_subscriptions uq_tenant_subscriptions_tenant_id; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT uq_tenant_subscriptions_tenant_id UNIQUE (tenant_id);


--
-- Name: tenants uq_tenants_slug; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT uq_tenants_slug UNIQUE (slug);


--
-- Name: workflow_steps workflow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: hive_vector_documents_collection_name_idx; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX hive_vector_documents_collection_name_idx ON public.hive_vector_documents USING btree (collection_name);


--
-- Name: hive_vector_documents_embedding_hnsw_idx; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX hive_vector_documents_embedding_hnsw_idx ON public.hive_vector_documents USING hnsw (embedding public.vector_cosine_ops);


--
-- Name: ix_agent_suggestions_proposal_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_proposal_type ON public.agent_suggestions USING btree (proposal_type);


--
-- Name: ix_agent_suggestions_proposed_by_role; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_proposed_by_role ON public.agent_suggestions USING btree (proposed_by_role);


--
-- Name: ix_agent_suggestions_risk_level; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_risk_level ON public.agent_suggestions USING btree (risk_level);


--
-- Name: ix_agent_suggestions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_status ON public.agent_suggestions USING btree (status);


--
-- Name: ix_agent_suggestions_sub_agent_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_sub_agent_session_id ON public.agent_suggestions USING btree (sub_agent_session_id);


--
-- Name: ix_agent_suggestions_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_supervisor_session_id ON public.agent_suggestions USING btree (supervisor_session_id);


--
-- Name: ix_agent_suggestions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_tenant_id ON public.agent_suggestions USING btree (tenant_id);


--
-- Name: ix_agent_templates_category; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_templates_category ON public.agent_templates USING btree (category);


--
-- Name: ix_agent_templates_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_templates_tenant_id ON public.agent_templates USING btree (tenant_id);


--
-- Name: ix_agents_swarm_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agents_swarm_id ON public.agents USING btree (swarm_id);


--
-- Name: ix_browser_automation_actions_action_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_action_type ON public.browser_automation_actions USING btree (action_type);


--
-- Name: ix_browser_automation_actions_browser_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_browser_session_id ON public.browser_automation_actions USING btree (browser_session_id);


--
-- Name: ix_browser_automation_actions_occurred_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_occurred_at ON public.browser_automation_actions USING btree (occurred_at);


--
-- Name: ix_browser_automation_actions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_status ON public.browser_automation_actions USING btree (status);


--
-- Name: ix_browser_automation_actions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_tenant_id ON public.browser_automation_actions USING btree (tenant_id);


--
-- Name: ix_browser_automation_sessions_mode; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_mode ON public.browser_automation_sessions USING btree (mode);


--
-- Name: ix_browser_automation_sessions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_status ON public.browser_automation_sessions USING btree (status);


--
-- Name: ix_browser_automation_sessions_sub_agent_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_sub_agent_session_id ON public.browser_automation_sessions USING btree (sub_agent_session_id);


--
-- Name: ix_browser_automation_sessions_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_supervisor_session_id ON public.browser_automation_sessions USING btree (supervisor_session_id);


--
-- Name: ix_browser_automation_sessions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_tenant_id ON public.browser_automation_sessions USING btree (tenant_id);


--
-- Name: ix_connector_vault_entries_credential_kind; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_credential_kind ON public.connector_vault_entries USING btree (credential_kind);


--
-- Name: ix_connector_vault_entries_dashboard_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_dashboard_user_id ON public.connector_vault_entries USING btree (dashboard_user_id);


--
-- Name: ix_connector_vault_entries_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_slug ON public.connector_vault_entries USING btree (slug);


--
-- Name: ix_connector_vault_entries_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_tenant_id ON public.connector_vault_entries USING btree (tenant_id);


--
-- Name: ix_cost_records_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_cost_records_tenant_id ON public.cost_records USING btree (tenant_id);


--
-- Name: ix_curated_memory_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_curated_memory_tenant_id ON public.curated_memory USING btree (tenant_id);


--
-- Name: ix_dashboard_api_keys_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_api_keys_user_id ON public.dashboard_api_keys USING btree (user_id);


--
-- Name: ix_dashboard_user_tenants_dashboard_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_user_tenants_dashboard_user_id ON public.dashboard_user_tenants USING btree (dashboard_user_id);


--
-- Name: ix_dashboard_user_tenants_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_user_tenants_tenant_id ON public.dashboard_user_tenants USING btree (tenant_id);


--
-- Name: ix_dashboard_users_active_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_users_active_tenant_id ON public.dashboard_users USING btree (active_tenant_id);


--
-- Name: ix_dashboard_users_email; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_users_email ON public.dashboard_users USING btree (email);


--
-- Name: ix_dream_cycles_started_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_cycles_started_at ON public.dream_cycles USING btree (started_at);


--
-- Name: ix_dream_cycles_started_at_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_cycles_started_at_status ON public.dream_cycles USING btree (started_at, status);


--
-- Name: ix_dream_cycles_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_cycles_status ON public.dream_cycles USING btree (status);


--
-- Name: ix_dream_cycles_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_cycles_tenant_id ON public.dream_cycles USING btree (tenant_id);


--
-- Name: ix_dream_cycles_tenant_started_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_cycles_tenant_started_at ON public.dream_cycles USING btree (tenant_id, started_at);


--
-- Name: ix_dream_insights_cycle_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_insights_cycle_id ON public.dream_insights USING btree (cycle_id);


--
-- Name: ix_dream_insights_source_kind; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_insights_source_kind ON public.dream_insights USING btree (source_kind);


--
-- Name: ix_dream_insights_source_kind_created_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_insights_source_kind_created_at ON public.dream_insights USING btree (source_kind, created_at);


--
-- Name: ix_dream_insights_tenant_created_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_insights_tenant_created_at ON public.dream_insights USING btree (tenant_id, created_at);


--
-- Name: ix_dream_insights_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dream_insights_tenant_id ON public.dream_insights USING btree (tenant_id);


--
-- Name: ix_dynamic_connectors_is_active_idx; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dynamic_connectors_is_active_idx ON public.dynamic_connectors USING btree (is_active);


--
-- Name: ix_dynamic_connectors_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dynamic_connectors_slug ON public.dynamic_connectors USING btree (slug);


--
-- Name: ix_dynamic_connectors_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dynamic_connectors_tenant_id ON public.dynamic_connectors USING btree (tenant_id);


--
-- Name: ix_external_outputs_dashboard_user_created; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_outputs_dashboard_user_created ON public.external_outputs USING btree (dashboard_user_id, created_at);


--
-- Name: ix_external_outputs_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_outputs_tenant_id ON public.external_outputs USING btree (tenant_id);


--
-- Name: ix_external_project_api_keys_project_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_api_keys_project_id ON public.external_project_api_keys USING btree (project_id);


--
-- Name: ix_external_project_api_keys_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_api_keys_tenant_id ON public.external_project_api_keys USING btree (tenant_id);


--
-- Name: ix_external_project_run_audit_api_key_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_api_key_id ON public.external_project_run_audit USING btree (api_key_id);


--
-- Name: ix_external_project_run_audit_created_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_created_at ON public.external_project_run_audit USING btree (created_at);


--
-- Name: ix_external_project_run_audit_project_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_project_id ON public.external_project_run_audit USING btree (project_id);


--
-- Name: ix_external_project_run_audit_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_tenant_id ON public.external_project_run_audit USING btree (tenant_id);


--
-- Name: ix_external_projects_owner_dashboard_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_owner_dashboard_user_id ON public.external_projects USING btree (owner_dashboard_user_id);


--
-- Name: ix_external_projects_project_kind; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_project_kind ON public.external_projects USING btree (project_kind);


--
-- Name: ix_external_projects_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_slug ON public.external_projects USING btree (slug);


--
-- Name: ix_external_projects_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_tenant_id ON public.external_projects USING btree (tenant_id);


--
-- Name: ix_foragers_name; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_foragers_name ON public.foragers USING btree (name);


--
-- Name: ix_foragers_source_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_foragers_source_type ON public.foragers USING btree (source_type);


--
-- Name: ix_foragers_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_foragers_tenant_id ON public.foragers USING btree (tenant_id);


--
-- Name: ix_goal_audit_results_goal_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_goal_audit_results_goal_id ON public.goal_audit_results USING btree (goal_id);


--
-- Name: ix_goal_audit_results_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_goal_audit_results_tenant_id ON public.goal_audit_results USING btree (tenant_id);


--
-- Name: ix_goals_root_task_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_goals_root_task_id ON public.goals USING btree (root_task_id);


--
-- Name: ix_goals_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_goals_status ON public.goals USING btree (status);


--
-- Name: ix_goals_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_goals_tenant_id ON public.goals USING btree (tenant_id);


--
-- Name: ix_goals_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_goals_user_id ON public.goals USING btree (user_id);


--
-- Name: ix_hive_async_workflow_runs_celery_task_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_hive_async_workflow_runs_celery_task_id ON public.hive_async_workflow_runs USING btree (celery_task_id);


--
-- Name: ix_knowledge_items_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_knowledge_items_tenant_id ON public.knowledge_items USING btree (tenant_id);


--
-- Name: ix_knowledge_items_topic_tags_gin; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_knowledge_items_topic_tags_gin ON public.knowledge_items USING gin (topic_tags);


--
-- Name: ix_learning_logs_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_learning_logs_tenant_id ON public.learning_logs USING btree (tenant_id);


--
-- Name: ix_memory_evolution_proposals_approved_by_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_approved_by_user_id ON public.memory_evolution_proposals USING btree (approved_by_user_id);


--
-- Name: ix_memory_evolution_proposals_proposal_kind; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_proposal_kind ON public.memory_evolution_proposals USING btree (proposal_kind);


--
-- Name: ix_memory_evolution_proposals_proposed_by_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_proposed_by_user_id ON public.memory_evolution_proposals USING btree (proposed_by_user_id);


--
-- Name: ix_memory_evolution_proposals_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_status ON public.memory_evolution_proposals USING btree (status);


--
-- Name: ix_memory_evolution_proposals_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_tenant_id ON public.memory_evolution_proposals USING btree (tenant_id);


--
-- Name: ix_operator_external_apis_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_operator_external_apis_user_id ON public.operator_external_apis USING btree (user_id);


--
-- Name: ix_paper_trading_accounts_project_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_paper_trading_accounts_project_id ON public.paper_trading_accounts USING btree (project_id);


--
-- Name: ix_paper_trading_accounts_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_paper_trading_accounts_tenant_id ON public.paper_trading_accounts USING btree (tenant_id);


--
-- Name: ix_paper_trading_fills_account_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_paper_trading_fills_account_id ON public.paper_trading_fills USING btree (account_id);


--
-- Name: ix_paper_trading_fills_created_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_paper_trading_fills_created_at ON public.paper_trading_fills USING btree (created_at);


--
-- Name: ix_paper_trading_fills_project_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_paper_trading_fills_project_id ON public.paper_trading_fills USING btree (project_id);


--
-- Name: ix_paper_trading_fills_symbol; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_paper_trading_fills_symbol ON public.paper_trading_fills USING btree (symbol);


--
-- Name: ix_paper_trading_fills_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_paper_trading_fills_tenant_id ON public.paper_trading_fills USING btree (tenant_id);


--
-- Name: ix_pending_review_items_status_created; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_pending_review_items_status_created ON public.pending_review_items USING btree (status, created_at);


--
-- Name: ix_pending_review_items_swarm_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_pending_review_items_swarm_id ON public.pending_review_items USING btree (swarm_id);


--
-- Name: ix_pending_review_items_task_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_pending_review_items_task_id ON public.pending_review_items USING btree (task_id);


--
-- Name: ix_platform_feature_policies_feature_key; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_platform_feature_policies_feature_key ON public.platform_feature_policies USING btree (feature_key);


--
-- Name: ix_platform_feature_policies_profile_key; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_platform_feature_policies_profile_key ON public.platform_feature_policies USING btree (profile_key);


--
-- Name: ix_pollen_rewards_agent_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_pollen_rewards_agent_id ON public.pollen_rewards USING btree (agent_id);


--
-- Name: ix_pollen_rewards_verified_reward; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_pollen_rewards_verified_reward ON public.pollen_rewards USING btree (verified_reward);


--
-- Name: ix_public_share_links_created_by_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_created_by_user_id ON public.public_share_links USING btree (created_by_user_id);


--
-- Name: ix_public_share_links_resource_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_resource_id ON public.public_share_links USING btree (resource_id);


--
-- Name: ix_public_share_links_resource_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_resource_type ON public.public_share_links USING btree (resource_type);


--
-- Name: ix_public_share_links_share_token; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_share_token ON public.public_share_links USING btree (share_token);


--
-- Name: ix_public_share_links_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_tenant_id ON public.public_share_links USING btree (tenant_id);


--
-- Name: ix_recipes_topic_tags_gin; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_recipes_topic_tags_gin ON public.recipes USING gin (topic_tags);


--
-- Name: ix_skill_marketplace_listings_publisher_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_skill_marketplace_listings_publisher_tenant_id ON public.skill_marketplace_listings USING btree (publisher_tenant_id);


--
-- Name: ix_skill_marketplace_listings_recipe_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_skill_marketplace_listings_recipe_id ON public.skill_marketplace_listings USING btree (recipe_id);


--
-- Name: ix_skill_marketplace_listings_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_skill_marketplace_listings_status ON public.skill_marketplace_listings USING btree (status);


--
-- Name: ix_skill_purchases_recipe_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_skill_purchases_recipe_id ON public.skill_purchases USING btree (recipe_id);


--
-- Name: ix_skill_purchases_stripe_checkout_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_skill_purchases_stripe_checkout_session_id ON public.skill_purchases USING btree (stripe_checkout_session_id);


--
-- Name: ix_skill_purchases_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_skill_purchases_tenant_id ON public.skill_purchases USING btree (tenant_id);


--
-- Name: ix_sub_agent_sessions_role; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_role ON public.sub_agent_sessions USING btree (role);


--
-- Name: ix_sub_agent_sessions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_status ON public.sub_agent_sessions USING btree (status);


--
-- Name: ix_sub_agent_sessions_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_supervisor_session_id ON public.sub_agent_sessions USING btree (supervisor_session_id);


--
-- Name: ix_sub_agent_sessions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_tenant_id ON public.sub_agent_sessions USING btree (tenant_id);


--
-- Name: ix_supervisor_routines_created_by_subject; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_created_by_subject ON public.supervisor_routines USING btree (created_by_subject);


--
-- Name: ix_supervisor_routines_is_active; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_is_active ON public.supervisor_routines USING btree (is_active);


--
-- Name: ix_supervisor_routines_name; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_name ON public.supervisor_routines USING btree (name);


--
-- Name: ix_supervisor_routines_next_run_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_next_run_at ON public.supervisor_routines USING btree (next_run_at);


--
-- Name: ix_supervisor_routines_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_tenant_id ON public.supervisor_routines USING btree (tenant_id);


--
-- Name: ix_supervisor_session_events_event_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_event_type ON public.supervisor_session_events USING btree (event_type);


--
-- Name: ix_supervisor_session_events_occurred_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_occurred_at ON public.supervisor_session_events USING btree (occurred_at);


--
-- Name: ix_supervisor_session_events_sub_agent_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_sub_agent_session_id ON public.supervisor_session_events USING btree (sub_agent_session_id);


--
-- Name: ix_supervisor_session_events_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_supervisor_session_id ON public.supervisor_session_events USING btree (supervisor_session_id);


--
-- Name: ix_supervisor_session_events_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_tenant_id ON public.supervisor_session_events USING btree (tenant_id);


--
-- Name: ix_supervisor_sessions_created_by_subject; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_sessions_created_by_subject ON public.supervisor_sessions USING btree (created_by_subject);


--
-- Name: ix_supervisor_sessions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_sessions_status ON public.supervisor_sessions USING btree (status);


--
-- Name: ix_supervisor_sessions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_sessions_tenant_id ON public.supervisor_sessions USING btree (tenant_id);


--
-- Name: ix_task_final_deliverables_lineage_created; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_task_final_deliverables_lineage_created ON public.task_final_deliverables USING btree (lineage_id, created_at);


--
-- Name: ix_task_final_deliverables_user_created; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_task_final_deliverables_user_created ON public.task_final_deliverables USING btree (dashboard_user_id, created_at);


--
-- Name: ix_tasks_swarm_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tasks_swarm_id ON public.tasks USING btree (swarm_id);


--
-- Name: ix_tasks_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tasks_tenant_id ON public.tasks USING btree (tenant_id);


--
-- Name: ix_tasks_workflow_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tasks_workflow_id ON public.tasks USING btree (workflow_id);


--
-- Name: ix_tenant_audit_logs_action; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_audit_logs_action ON public.tenant_audit_logs USING btree (action);


--
-- Name: ix_tenant_audit_logs_actor_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_audit_logs_actor_user_id ON public.tenant_audit_logs USING btree (actor_user_id);


--
-- Name: ix_tenant_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_audit_logs_tenant_id ON public.tenant_audit_logs USING btree (tenant_id);


--
-- Name: ix_tenant_invites_email; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_invites_email ON public.tenant_invites USING btree (email);


--
-- Name: ix_tenant_invites_invite_token; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_invites_invite_token ON public.tenant_invites USING btree (invite_token);


--
-- Name: ix_tenant_invites_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_invites_tenant_id ON public.tenant_invites USING btree (tenant_id);


--
-- Name: ix_tenant_subscriptions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_status ON public.tenant_subscriptions USING btree (status);


--
-- Name: ix_tenant_subscriptions_stripe_customer_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_stripe_customer_id ON public.tenant_subscriptions USING btree (stripe_customer_id);


--
-- Name: ix_tenant_subscriptions_stripe_subscription_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_stripe_subscription_id ON public.tenant_subscriptions USING btree (stripe_subscription_id);


--
-- Name: ix_tenant_subscriptions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_tenant_id ON public.tenant_subscriptions USING btree (tenant_id);


--
-- Name: ix_tenant_subscriptions_tier; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_tier ON public.tenant_subscriptions USING btree (tier);


--
-- Name: ix_tenants_platform_mode; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenants_platform_mode ON public.tenants USING btree (platform_mode);


--
-- Name: ix_tenants_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: ix_uq_dashboard_api_keys_user_source_active; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE UNIQUE INDEX ix_uq_dashboard_api_keys_user_source_active ON public.dashboard_api_keys USING btree (user_id, source_name) WHERE ((source_name IS NOT NULL) AND (revoked_at IS NULL));


--
-- Name: ix_workflow_steps_workflow_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_workflow_steps_workflow_id ON public.workflow_steps USING btree (workflow_id);


--
-- Name: agent_configs agent_configs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT agent_configs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_suggestions agent_suggestions_sub_agent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_sub_agent_session_id_fkey FOREIGN KEY (sub_agent_session_id) REFERENCES public.sub_agent_sessions(id) ON DELETE SET NULL;


--
-- Name: agent_suggestions agent_suggestions_supervisor_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_supervisor_session_id_fkey FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE SET NULL;


--
-- Name: agent_suggestions agent_suggestions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: agent_templates agent_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_templates
    ADD CONSTRAINT agent_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: browser_automation_actions browser_automation_actions_browser_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_actions
    ADD CONSTRAINT browser_automation_actions_browser_session_id_fkey FOREIGN KEY (browser_session_id) REFERENCES public.browser_automation_sessions(id) ON DELETE CASCADE;


--
-- Name: browser_automation_actions browser_automation_actions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_actions
    ADD CONSTRAINT browser_automation_actions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: browser_automation_sessions browser_automation_sessions_sub_agent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_sub_agent_session_id_fkey FOREIGN KEY (sub_agent_session_id) REFERENCES public.sub_agent_sessions(id) ON DELETE SET NULL;


--
-- Name: browser_automation_sessions browser_automation_sessions_supervisor_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_supervisor_session_id_fkey FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE SET NULL;


--
-- Name: browser_automation_sessions browser_automation_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: connector_vault_entries connector_vault_entries_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT connector_vault_entries_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: curated_memory curated_memory_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.curated_memory
    ADD CONSTRAINT curated_memory_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: curated_memory curated_memory_updated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.curated_memory
    ADD CONSTRAINT curated_memory_updated_by_user_id_fkey FOREIGN KEY (updated_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: dashboard_api_keys dashboard_api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_api_keys
    ADD CONSTRAINT dashboard_api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: dashboard_user_tenants dashboard_user_tenants_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT dashboard_user_tenants_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: dashboard_user_tenants dashboard_user_tenants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT dashboard_user_tenants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: dream_insights dream_insights_cycle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dream_insights
    ADD CONSTRAINT dream_insights_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES public.dream_cycles(id) ON DELETE CASCADE;


--
-- Name: external_outputs external_outputs_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_outputs
    ADD CONSTRAINT external_outputs_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: agents fk_agents_swarm_id_sub_swarms; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_swarm_id_sub_swarms FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id);


--
-- Name: connector_vault_entries fk_connector_vault_entries_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT fk_connector_vault_entries_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: cost_records fk_cost_records_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT fk_cost_records_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: cost_records fk_cost_records_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT fk_cost_records_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: cost_records fk_cost_records_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT fk_cost_records_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: dashboard_users fk_dashboard_users_active_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT fk_dashboard_users_active_tenant_id FOREIGN KEY (active_tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: dynamic_connectors fk_dynamic_connectors_dashboard_user_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT fk_dynamic_connectors_dashboard_user_id FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id);


--
-- Name: dynamic_connectors fk_dynamic_connectors_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT fk_dynamic_connectors_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_outputs fk_external_outputs_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_outputs
    ADD CONSTRAINT fk_external_outputs_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_project_api_keys fk_external_project_api_keys_project_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_api_keys
    ADD CONSTRAINT fk_external_project_api_keys_project_id FOREIGN KEY (project_id) REFERENCES public.external_projects(id) ON DELETE CASCADE;


--
-- Name: external_project_api_keys fk_external_project_api_keys_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_api_keys
    ADD CONSTRAINT fk_external_project_api_keys_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_project_run_audit fk_external_project_run_audit_api_key_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT fk_external_project_run_audit_api_key_id FOREIGN KEY (api_key_id) REFERENCES public.external_project_api_keys(id) ON DELETE SET NULL;


--
-- Name: external_project_run_audit fk_external_project_run_audit_project_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT fk_external_project_run_audit_project_id FOREIGN KEY (project_id) REFERENCES public.external_projects(id) ON DELETE CASCADE;


--
-- Name: external_project_run_audit fk_external_project_run_audit_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT fk_external_project_run_audit_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_projects fk_external_projects_owner_dashboard_user_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT fk_external_projects_owner_dashboard_user_id FOREIGN KEY (owner_dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: external_projects fk_external_projects_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT fk_external_projects_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: hive_async_workflow_runs fk_hive_async_workflow_runs_hive_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT fk_hive_async_workflow_runs_hive_task_id FOREIGN KEY (hive_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: hive_async_workflow_runs fk_hive_async_workflow_runs_swarm_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT fk_hive_async_workflow_runs_swarm_id FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id) ON DELETE RESTRICT;


--
-- Name: hive_async_workflow_runs fk_hive_async_workflow_runs_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT fk_hive_async_workflow_runs_workflow_id FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE RESTRICT;


--
-- Name: imitation_events fk_imitation_copied_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT fk_imitation_copied_agent_id FOREIGN KEY (copied_agent_id) REFERENCES public.agents(id);


--
-- Name: imitation_events fk_imitation_copier_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT fk_imitation_copier_agent_id FOREIGN KEY (copier_agent_id) REFERENCES public.agents(id);


--
-- Name: imitation_events fk_imitation_recipe_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT fk_imitation_recipe_id FOREIGN KEY (recipe_id) REFERENCES public.recipes(id);


--
-- Name: knowledge_items fk_knowledge_items_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT fk_knowledge_items_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: learning_logs fk_learning_logs_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT fk_learning_logs_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: learning_logs fk_learning_logs_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT fk_learning_logs_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: learning_logs fk_learning_logs_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT fk_learning_logs_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: pollen_rewards fk_pollen_rewards_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT fk_pollen_rewards_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: pollen_rewards fk_pollen_rewards_source_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT fk_pollen_rewards_source_agent_id FOREIGN KEY (source_agent_id) REFERENCES public.agents(id);


--
-- Name: pollen_rewards fk_pollen_rewards_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT fk_pollen_rewards_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: recipes fk_recipes_created_by_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT fk_recipes_created_by_agent_id FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id);


--
-- Name: simulations fk_simulations_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT fk_simulations_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: skill_purchases fk_skill_purchases_marketplace_listing_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_purchases
    ADD CONSTRAINT fk_skill_purchases_marketplace_listing_id FOREIGN KEY (marketplace_listing_id) REFERENCES public.skill_marketplace_listings(id) ON DELETE SET NULL;


--
-- Name: sub_agent_sessions fk_sub_agent_sessions_supervisor_session_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_agent_sessions
    ADD CONSTRAINT fk_sub_agent_sessions_supervisor_session_id FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE CASCADE;


--
-- Name: sub_agent_sessions fk_sub_agent_sessions_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_agent_sessions
    ADD CONSTRAINT fk_sub_agent_sessions_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: sub_swarms fk_sub_swarms_queen_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_swarms
    ADD CONSTRAINT fk_sub_swarms_queen_agent_id FOREIGN KEY (queen_agent_id) REFERENCES public.agents(id);


--
-- Name: supervisor_routines fk_supervisor_routines_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_routines
    ADD CONSTRAINT fk_supervisor_routines_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: supervisor_session_events fk_supervisor_session_events_sub_agent_session_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT fk_supervisor_session_events_sub_agent_session_id FOREIGN KEY (sub_agent_session_id) REFERENCES public.sub_agent_sessions(id) ON DELETE CASCADE;


--
-- Name: supervisor_session_events fk_supervisor_session_events_supervisor_session_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT fk_supervisor_session_events_supervisor_session_id FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE CASCADE;


--
-- Name: supervisor_session_events fk_supervisor_session_events_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT fk_supervisor_session_events_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: supervisor_sessions fk_supervisor_sessions_swarm_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT fk_supervisor_sessions_swarm_id FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id) ON DELETE SET NULL;


--
-- Name: supervisor_sessions fk_supervisor_sessions_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT fk_supervisor_sessions_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: supervisor_sessions fk_supervisor_sessions_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT fk_supervisor_sessions_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tasks fk_tasks_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: tasks fk_tasks_parent_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_parent_task_id FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id);


--
-- Name: tasks fk_tasks_recipe_used_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_recipe_used_id FOREIGN KEY (recipe_used_id) REFERENCES public.recipes(id);


--
-- Name: tasks fk_tasks_swarm_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_swarm_id FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id);


--
-- Name: tasks fk_tasks_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tasks fk_tasks_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_workflow_id FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: workflow_steps fk_workflow_steps_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT fk_workflow_steps_workflow_id FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: workflows fk_workflows_matching_recipe_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_workflows_matching_recipe_id FOREIGN KEY (matching_recipe_id) REFERENCES public.recipes(id);


--
-- Name: foragers foragers_agent_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.foragers
    ADD CONSTRAINT foragers_agent_template_id_fkey FOREIGN KEY (agent_template_id) REFERENCES public.agent_templates(id) ON DELETE SET NULL;


--
-- Name: foragers foragers_supervisor_routine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.foragers
    ADD CONSTRAINT foragers_supervisor_routine_id_fkey FOREIGN KEY (supervisor_routine_id) REFERENCES public.supervisor_routines(id) ON DELETE SET NULL;


--
-- Name: foragers foragers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.foragers
    ADD CONSTRAINT foragers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: goal_audit_results goal_audit_results_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.goal_audit_results
    ADD CONSTRAINT goal_audit_results_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.goals(id) ON DELETE CASCADE;


--
-- Name: goal_audit_results goal_audit_results_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.goal_audit_results
    ADD CONSTRAINT goal_audit_results_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: goals goals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: goals goals_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: memory_evolution_proposals memory_evolution_proposals_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: memory_evolution_proposals memory_evolution_proposals_proposed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_proposed_by_user_id_fkey FOREIGN KEY (proposed_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: memory_evolution_proposals memory_evolution_proposals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: operator_external_apis operator_external_apis_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.operator_external_apis
    ADD CONSTRAINT operator_external_apis_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: paper_trading_accounts paper_trading_accounts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.paper_trading_accounts
    ADD CONSTRAINT paper_trading_accounts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.external_projects(id) ON DELETE CASCADE;


--
-- Name: paper_trading_fills paper_trading_fills_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.paper_trading_fills
    ADD CONSTRAINT paper_trading_fills_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.paper_trading_accounts(id) ON DELETE CASCADE;


--
-- Name: paper_trading_fills paper_trading_fills_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.paper_trading_fills
    ADD CONSTRAINT paper_trading_fills_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.external_projects(id) ON DELETE CASCADE;


--
-- Name: pending_review_items pending_review_items_simulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pending_review_items
    ADD CONSTRAINT pending_review_items_simulation_id_fkey FOREIGN KEY (simulation_id) REFERENCES public.simulations(id) ON DELETE SET NULL;


--
-- Name: pending_review_items pending_review_items_swarm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pending_review_items
    ADD CONSTRAINT pending_review_items_swarm_id_fkey FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id) ON DELETE CASCADE;


--
-- Name: pending_review_items pending_review_items_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pending_review_items
    ADD CONSTRAINT pending_review_items_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: pending_review_items pending_review_items_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pending_review_items
    ADD CONSTRAINT pending_review_items_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: public_share_links public_share_links_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT public_share_links_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: public_share_links public_share_links_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT public_share_links_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: skill_marketplace_listings skill_marketplace_listings_publisher_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_marketplace_listings
    ADD CONSTRAINT skill_marketplace_listings_publisher_tenant_id_fkey FOREIGN KEY (publisher_tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: skill_marketplace_listings skill_marketplace_listings_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_marketplace_listings
    ADD CONSTRAINT skill_marketplace_listings_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: skill_purchases skill_purchases_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_purchases
    ADD CONSTRAINT skill_purchases_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: skill_purchases skill_purchases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.skill_purchases
    ADD CONSTRAINT skill_purchases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: task_final_deliverables task_final_deliverables_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT task_final_deliverables_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: task_final_deliverables task_final_deliverables_source_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT task_final_deliverables_source_task_id_fkey FOREIGN KEY (source_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tenant_audit_logs tenant_audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: tenant_audit_logs tenant_audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tenant_invites tenant_invites_invited_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT tenant_invites_invited_by_user_id_fkey FOREIGN KEY (invited_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: tenant_invites tenant_invites_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT tenant_invites_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tenant_subscriptions tenant_subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict ugEhY1BEbvvcR46HapkHpAinAfTKKSyamAafHdUdun9dVBZ4zHS3bvpIam8gBsD

