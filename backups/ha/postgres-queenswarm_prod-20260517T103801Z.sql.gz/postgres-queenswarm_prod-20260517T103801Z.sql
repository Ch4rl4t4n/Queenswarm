--
-- PostgreSQL database dump
--

\restrict 8xl79xJxaGuCeKAcdePQb4dbvx2bRNeOixjNxphqHQCXQdSkFkPacPMBJc8d9aE

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg12+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_configs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.agent_configs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    system_prompt text NOT NULL,
    user_prompt_template text,
    tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    output_format character varying(50) DEFAULT 'text'::character varying NOT NULL,
    output_destination character varying(200) DEFAULT 'dashboard'::character varying NOT NULL,
    output_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    schedule_type character varying(50) DEFAULT 'on_demand'::character varying NOT NULL,
    schedule_value character varying(200),
    is_active boolean DEFAULT true NOT NULL,
    last_run_at timestamp with time zone,
    last_run_result jsonb,
    run_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.agent_configs OWNER TO queenswarm;

--
-- Name: agent_suggestions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.agent_suggestions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid,
    sub_agent_session_id uuid,
    proposal_type character varying(48) NOT NULL,
    proposed_by_role character varying(64) NOT NULL,
    title character varying(260) NOT NULL,
    description text NOT NULL,
    proposal_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_level character varying(16) NOT NULL,
    impact_score double precision NOT NULL,
    status character varying(24) NOT NULL,
    requires_manual_approval boolean DEFAULT false NOT NULL,
    evaluation_reason character varying(800),
    reviewed_by_subject character varying(512),
    reviewed_at timestamp with time zone,
    implemented_at timestamp with time zone
);


ALTER TABLE public.agent_suggestions OWNER TO queenswarm;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.agents (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(100) NOT NULL,
    role character varying(48) NOT NULL,
    status character varying(32) DEFAULT 'idle'::character varying NOT NULL,
    swarm_id uuid,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    pollen_points double precision DEFAULT 0.0 NOT NULL,
    performance_score double precision DEFAULT 0.0 NOT NULL,
    last_synced_at timestamp with time zone,
    last_active_at timestamp with time zone
);


ALTER TABLE public.agents OWNER TO queenswarm;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.alembic_version (
    version_num character varying(128) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO queenswarm;

--
-- Name: browser_automation_actions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.browser_automation_actions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    browser_session_id uuid NOT NULL,
    action_type character varying(32) NOT NULL,
    status character varying(24) NOT NULL,
    requires_approval boolean DEFAULT false NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_summary character varying(2000),
    occurred_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.browser_automation_actions OWNER TO queenswarm;

--
-- Name: browser_automation_sessions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.browser_automation_sessions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid,
    sub_agent_session_id uuid,
    created_by_subject character varying(512),
    mode character varying(16) NOT NULL,
    status character varying(24) NOT NULL,
    start_url character varying(2048),
    current_url character varying(2048),
    allowed_domains jsonb DEFAULT '[]'::jsonb NOT NULL,
    blocked_reason character varying(800),
    expires_at timestamp with time zone,
    max_actions integer NOT NULL,
    actions_used integer NOT NULL,
    pending_approval_action jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_snapshot_text text,
    last_screenshot_base64 text,
    is_headless boolean DEFAULT true NOT NULL,
    started_at timestamp with time zone,
    ended_at timestamp with time zone
);


ALTER TABLE public.browser_automation_sessions OWNER TO queenswarm;

--
-- Name: budgets; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.budgets (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    period character varying(32) NOT NULL,
    limit_usd double precision NOT NULL,
    spent_usd double precision DEFAULT 0.0 NOT NULL,
    reset_at timestamp with time zone NOT NULL
);


ALTER TABLE public.budgets OWNER TO queenswarm;

--
-- Name: connector_vault_entries; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.connector_vault_entries (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(128) NOT NULL,
    credential_kind character varying(32) NOT NULL,
    encrypted_payload text NOT NULL,
    dashboard_user_id uuid NOT NULL,
    label character varying(256),
    tenant_id uuid
);


ALTER TABLE public.connector_vault_entries OWNER TO queenswarm;

--
-- Name: cost_records; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.cost_records (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid,
    task_id uuid,
    llm_model character varying(100) NOT NULL,
    tokens_in integer DEFAULT 0 NOT NULL,
    tokens_out integer DEFAULT 0 NOT NULL,
    cost_usd double precision NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.cost_records OWNER TO queenswarm;

--
-- Name: dashboard_api_keys; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dashboard_api_keys (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    label character varying(160),
    secret_hash character varying(255) NOT NULL,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    source_name character varying(80)
);


ALTER TABLE public.dashboard_api_keys OWNER TO queenswarm;

--
-- Name: dashboard_user_tenants; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dashboard_user_tenants (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    dashboard_user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    role character varying(32) NOT NULL,
    joined_at timestamp with time zone NOT NULL
);


ALTER TABLE public.dashboard_user_tenants OWNER TO queenswarm;

--
-- Name: dashboard_users; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dashboard_users (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(160),
    totp_secret text,
    totp_verified_at timestamp with time zone,
    totp_required boolean DEFAULT true NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    timezone character varying(96),
    notification_prefs jsonb DEFAULT '{}'::jsonb,
    active_tenant_id uuid
);


ALTER TABLE public.dashboard_users OWNER TO queenswarm;

--
-- Name: dynamic_connectors; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.dynamic_connectors (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(160) NOT NULL,
    display_name character varying(256) NOT NULL,
    base_url text,
    auth_type character varying(32) NOT NULL,
    secrets_cipher text,
    mcp_manifest jsonb,
    allowed_manager_slugs jsonb,
    is_active boolean DEFAULT false NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    builtin_kind character varying(64),
    last_tested_at timestamp with time zone,
    dashboard_user_id uuid,
    tenant_id uuid
);


ALTER TABLE public.dynamic_connectors OWNER TO queenswarm;

--
-- Name: external_outputs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_outputs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    dashboard_user_id uuid NOT NULL,
    mission_id uuid NOT NULL,
    session_id uuid,
    text_report text NOT NULL,
    voice_script text,
    output_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    simulation_outcome jsonb,
    tags character varying(128)[] DEFAULT ARRAY[]::character varying[] NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.external_outputs OWNER TO queenswarm;

--
-- Name: external_project_api_keys; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_project_api_keys (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    label character varying(160),
    secret_hash character varying(255) NOT NULL,
    permissions jsonb DEFAULT '["run"]'::jsonb NOT NULL,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    tenant_id uuid
);


ALTER TABLE public.external_project_api_keys OWNER TO queenswarm;

--
-- Name: external_project_run_audit; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_project_run_audit (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    api_key_id uuid,
    action_slug character varying(160) NOT NULL,
    ok boolean NOT NULL,
    latency_ms integer NOT NULL,
    cost_usd numeric(12,6) DEFAULT '0'::numeric NOT NULL,
    human_approval_required boolean DEFAULT false NOT NULL,
    human_approved boolean,
    payload_excerpt text DEFAULT ''''''::text NOT NULL,
    result_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.external_project_run_audit OWNER TO queenswarm;

--
-- Name: external_projects; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.external_projects (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(128) NOT NULL,
    display_name character varying(256) NOT NULL,
    project_kind character varying(32) NOT NULL,
    owner_dashboard_user_id uuid NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    webhook_url text,
    webhook_secret_hash character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.external_projects OWNER TO queenswarm;

--
-- Name: hive_async_workflow_runs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.hive_async_workflow_runs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    celery_task_id character varying(96) NOT NULL,
    swarm_id uuid NOT NULL,
    workflow_id uuid NOT NULL,
    hive_task_id uuid,
    requested_by_subject character varying(512),
    lifecycle character varying(32) DEFAULT 'queued'::character varying NOT NULL,
    result_snapshot jsonb,
    error_text text,
    finished_at timestamp with time zone
);


ALTER TABLE public.hive_async_workflow_runs OWNER TO queenswarm;

--
-- Name: hive_llm_secrets; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.hive_llm_secrets (
    provider character varying(32) NOT NULL,
    ciphertext text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hive_llm_secrets OWNER TO queenswarm;

--
-- Name: hive_vector_documents; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.hive_vector_documents (
    id text DEFAULT (gen_random_uuid())::text NOT NULL,
    collection_name text NOT NULL,
    document text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    embedding public.vector(384) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.hive_vector_documents OWNER TO queenswarm;

--
-- Name: imitation_events; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.imitation_events (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    copier_agent_id uuid NOT NULL,
    copied_agent_id uuid NOT NULL,
    recipe_id uuid,
    outcome character varying(50)
);


ALTER TABLE public.imitation_events OWNER TO queenswarm;

--
-- Name: knowledge_items; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.knowledge_items (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_url character varying(2048),
    source_type character varying(50) NOT NULL,
    content_text text NOT NULL,
    embedding_id character varying(160),
    neo4j_node_id character varying(160),
    confidence_score double precision DEFAULT 0.5 NOT NULL,
    topic_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    decay_factor double precision DEFAULT 1.0 NOT NULL,
    scraped_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    tenant_id uuid
);


ALTER TABLE public.knowledge_items OWNER TO queenswarm;

--
-- Name: learning_logs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.learning_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    task_id uuid,
    insight_text text NOT NULL,
    applied_at timestamp with time zone,
    pollen_earned double precision DEFAULT 0.0 NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.learning_logs OWNER TO queenswarm;

--
-- Name: memory_evolution_proposals; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.memory_evolution_proposals (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    proposal_kind character varying(48) NOT NULL,
    title character varying(240) NOT NULL,
    summary character varying(2000) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(24) NOT NULL,
    importance_score double precision NOT NULL,
    requires_manual_approval boolean DEFAULT false NOT NULL,
    proposed_by_user_id uuid,
    approved_by_user_id uuid,
    approved_at timestamp with time zone
);


ALTER TABLE public.memory_evolution_proposals OWNER TO queenswarm;

--
-- Name: operator_external_apis; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.operator_external_apis (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(80) NOT NULL,
    label character varying(160) NOT NULL,
    ciphertext text NOT NULL,
    base_url character varying(512),
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.operator_external_apis OWNER TO queenswarm;

--
-- Name: pollen_rewards; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.pollen_rewards (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    agent_id uuid NOT NULL,
    task_id uuid,
    amount double precision NOT NULL,
    reason character varying(500) NOT NULL,
    source_agent_id uuid
);


ALTER TABLE public.pollen_rewards OWNER TO queenswarm;

--
-- Name: public_share_links; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.public_share_links (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    resource_type character varying(32) NOT NULL,
    resource_id uuid NOT NULL,
    share_token character varying(96) NOT NULL,
    created_by_user_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    expires_at timestamp with time zone,
    access_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.public_share_links OWNER TO queenswarm;

--
-- Name: recipes; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    topic_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    workflow_template jsonb NOT NULL,
    success_count integer DEFAULT 0 NOT NULL,
    fail_count integer DEFAULT 0 NOT NULL,
    avg_pollen_earned double precision DEFAULT 0.0 NOT NULL,
    embedding_id character varying(160),
    created_by_agent_id uuid,
    verified_at timestamp with time zone,
    last_used_at timestamp with time zone,
    is_deprecated boolean DEFAULT false NOT NULL
);


ALTER TABLE public.recipes OWNER TO queenswarm;

--
-- Name: simulations; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.simulations (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    task_id uuid,
    scenario jsonb NOT NULL,
    result_data jsonb,
    result_type character varying(32) NOT NULL,
    confidence_pct double precision DEFAULT 0.0 NOT NULL,
    docker_container_id character varying(128),
    duration_sec double precision,
    stdout text,
    stderr text
);


ALTER TABLE public.simulations OWNER TO queenswarm;

--
-- Name: sub_agent_sessions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.sub_agent_sessions (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid NOT NULL,
    role character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    runtime_mode character varying(16) DEFAULT 'inprocess'::character varying NOT NULL,
    toolset jsonb DEFAULT '[]'::jsonb NOT NULL,
    short_memory jsonb DEFAULT '{}'::jsonb NOT NULL,
    spawn_order integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    last_output text,
    error_text text,
    tenant_id uuid
);


ALTER TABLE public.sub_agent_sessions OWNER TO queenswarm;

--
-- Name: sub_swarms; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.sub_swarms (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(100) NOT NULL,
    purpose character varying(32) NOT NULL,
    local_memory jsonb DEFAULT '{}'::jsonb NOT NULL,
    queen_agent_id uuid,
    last_global_sync_at timestamp with time zone,
    total_pollen double precision DEFAULT 0.0 NOT NULL,
    member_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.sub_swarms OWNER TO queenswarm;

--
-- Name: supervisor_routines; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.supervisor_routines (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(160) NOT NULL,
    goal_template text NOT NULL,
    schedule_kind character varying(16) DEFAULT 'interval'::character varying NOT NULL,
    interval_seconds integer,
    cron_expr character varying(64),
    runtime_mode character varying(16) DEFAULT 'durable'::character varying NOT NULL,
    roles jsonb DEFAULT '[]'::jsonb NOT NULL,
    retrieval_contract character varying(200),
    skills jsonb DEFAULT '[]'::jsonb NOT NULL,
    context_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(24) DEFAULT 'idle'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by_subject character varying(512),
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    last_error text,
    tenant_id uuid
);


ALTER TABLE public.supervisor_routines OWNER TO queenswarm;

--
-- Name: supervisor_session_events; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.supervisor_session_events (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supervisor_session_id uuid NOT NULL,
    sub_agent_session_id uuid,
    event_type character varying(64) NOT NULL,
    level character varying(16) DEFAULT 'info'::character varying NOT NULL,
    message text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid
);


ALTER TABLE public.supervisor_session_events OWNER TO queenswarm;

--
-- Name: supervisor_sessions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.supervisor_sessions (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    goal text NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    runtime_mode character varying(16) DEFAULT 'inprocess'::character varying NOT NULL,
    created_by_subject character varying(512),
    context_summary jsonb DEFAULT '{}'::jsonb NOT NULL,
    swarm_id uuid,
    task_id uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_text text,
    tenant_id uuid
);


ALTER TABLE public.supervisor_sessions OWNER TO queenswarm;

--
-- Name: task_final_deliverables; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.task_final_deliverables (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    lineage_id uuid NOT NULL,
    version integer NOT NULL,
    dashboard_user_id uuid,
    source_task_id uuid,
    ballroom_session_id uuid,
    mission_id uuid,
    slug character varying(200) NOT NULL,
    title character varying(500) NOT NULL,
    markdown_body text NOT NULL,
    structured_json jsonb NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    voice_script text,
    chroma_embedding_id character varying(160),
    archive_relpath character varying(512)
);


ALTER TABLE public.task_final_deliverables OWNER TO queenswarm;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    title character varying(500) NOT NULL,
    task_type character varying(48) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    priority integer DEFAULT 5 NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb,
    agent_id uuid,
    swarm_id uuid,
    workflow_id uuid,
    parent_task_id uuid,
    pollen_awarded double precision DEFAULT 0.0 NOT NULL,
    recipe_used_id uuid,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_msg text,
    tenant_id uuid
);


ALTER TABLE public.tasks OWNER TO queenswarm;

--
-- Name: tenant_audit_logs; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenant_audit_logs (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid,
    actor_user_id uuid,
    action character varying(64) NOT NULL,
    target_type character varying(64) NOT NULL,
    target_ref character varying(255) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.tenant_audit_logs OWNER TO queenswarm;

--
-- Name: tenant_invites; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenant_invites (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_id uuid,
    email character varying(255) NOT NULL,
    role character varying(32) NOT NULL,
    invited_by_user_id uuid NOT NULL,
    invite_token character varying(128) NOT NULL,
    status character varying(24) NOT NULL
);


ALTER TABLE public.tenant_invites OWNER TO queenswarm;

--
-- Name: tenant_subscriptions; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenant_subscriptions (
    id uuid NOT NULL,
    tenant_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tier character varying(32) NOT NULL,
    status character varying(24) NOT NULL,
    stripe_customer_id character varying(128),
    stripe_subscription_id character varying(128),
    billing_cycle_anchor timestamp with time zone,
    period_end_at timestamp with time zone,
    limits_override jsonb DEFAULT '{}'::jsonb NOT NULL,
    feature_overrides jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.tenant_subscriptions OWNER TO queenswarm;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(128) NOT NULL,
    name character varying(256) NOT NULL,
    status character varying(24) NOT NULL
);


ALTER TABLE public.tenants OWNER TO queenswarm;

--
-- Name: workflow_steps; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.workflow_steps (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    workflow_id uuid NOT NULL,
    step_order integer NOT NULL,
    description text NOT NULL,
    agent_role character varying(48) NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    input_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_schema jsonb DEFAULT '{}'::jsonb NOT NULL,
    guardrails jsonb DEFAULT '{}'::jsonb NOT NULL,
    evaluation_criteria jsonb DEFAULT '{}'::jsonb NOT NULL,
    result jsonb,
    error_msg text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.workflow_steps OWNER TO queenswarm;

--
-- Name: workflows; Type: TABLE; Schema: public; Owner: queenswarm
--

CREATE TABLE public.workflows (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    original_task_text text NOT NULL,
    decomposition_rationale text,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    total_steps integer DEFAULT 0 NOT NULL,
    completed_steps integer DEFAULT 0 NOT NULL,
    parallelizable_groups jsonb DEFAULT '[]'::jsonb NOT NULL,
    matching_recipe_id uuid,
    estimated_duration_sec integer,
    actual_duration_sec integer
);


ALTER TABLE public.workflows OWNER TO queenswarm;

--
-- Data for Name: agent_configs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.agent_configs (id, created_at, updated_at, agent_id, system_prompt, user_prompt_template, tools, output_format, output_destination, output_config, schedule_type, schedule_value, is_active, last_run_at, last_run_result, run_count) FROM stdin;
2c33ab93-6181-476c-9e60-b46ad6ae6e08	2026-05-14 18:14:18.137783+00	2026-05-14 18:14:18.137783+00	fd2e8e4a-a266-4869-93d4-34f97114094c	You coordinate hive managers and workers on queenswarm.love. Interpret user goals, delegate to the right specialists, and return concise verified outcomes.	\N	[]	text	ballroom	{"hive_tier": "orchestrator"}	on_demand	\N	t	\N	\N	0
\.


--
-- Data for Name: agent_suggestions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.agent_suggestions (id, tenant_id, created_at, updated_at, supervisor_session_id, sub_agent_session_id, proposal_type, proposed_by_role, title, description, proposal_payload, risk_level, impact_score, status, requires_manual_approval, evaluation_reason, reviewed_by_subject, reviewed_at, implemented_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.agents (id, created_at, updated_at, name, role, status, swarm_id, config, pollen_points, performance_score, last_synced_at, last_active_at) FROM stdin;
fd2e8e4a-a266-4869-93d4-34f97114094c	2026-05-14 18:14:18.137783+00	2026-05-14 18:14:18.137783+00	Orchestrator	learner	idle	\N	{"hive_tier": "orchestrator", "hive_fixed": true}	0	0	\N	\N
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.alembic_version (version_num) FROM stdin;
0018_supervisor_routines
0026_supervisor_sessions_tenant_hotfix
\.


--
-- Data for Name: browser_automation_actions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.browser_automation_actions (id, tenant_id, created_at, updated_at, browser_session_id, action_type, status, requires_approval, payload, result_summary, occurred_at) FROM stdin;
\.


--
-- Data for Name: browser_automation_sessions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.browser_automation_sessions (id, tenant_id, created_at, updated_at, supervisor_session_id, sub_agent_session_id, created_by_subject, mode, status, start_url, current_url, allowed_domains, blocked_reason, expires_at, max_actions, actions_used, pending_approval_action, last_snapshot_text, last_screenshot_base64, is_headless, started_at, ended_at) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.budgets (id, created_at, updated_at, period, limit_usd, spent_usd, reset_at) FROM stdin;
\.


--
-- Data for Name: connector_vault_entries; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.connector_vault_entries (id, created_at, updated_at, slug, credential_kind, encrypted_payload, dashboard_user_id, label, tenant_id) FROM stdin;
\.


--
-- Data for Name: cost_records; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.cost_records (id, created_at, updated_at, agent_id, task_id, llm_model, tokens_in, tokens_out, cost_usd, tenant_id) FROM stdin;
90040c8b-eb8a-440e-9b0b-c8bc37465283	2026-05-14 20:35:06.209385+00	2026-05-14 20:35:06.209385+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
546d403e-b3e3-4bf5-9b59-40ea9071f55f	2026-05-14 20:53:31.365767+00	2026-05-14 20:53:31.365767+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	3791	0.019590000000000003	\N
1c69a0d2-8f98-4c13-a1ce-473739672069	2026-05-15 10:11:01.149395+00	2026-05-15 10:11:01.149395+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
5aae2187-7efb-4fe3-9b0b-9b2d6448c573	2026-05-15 10:13:28.628137+00	2026-05-15 10:13:28.628137+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
048eb8cb-0aeb-452d-8b05-bdc0389cc299	2026-05-16 21:21:38.490769+00	2026-05-16 21:21:38.490769+00	\N	\N	anthropic/claude-haiku-4-5-20251001	635	4096	0.021115000000000002	\N
\.


--
-- Data for Name: dashboard_api_keys; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dashboard_api_keys (id, created_at, updated_at, user_id, label, secret_hash, last_used_at, revoked_at, source_name) FROM stdin;
\.


--
-- Data for Name: dashboard_user_tenants; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dashboard_user_tenants (id, created_at, updated_at, dashboard_user_id, tenant_id, role, joined_at) FROM stdin;
b44462cc-898e-499d-bcf4-4aab04d335cf	2026-05-16 19:54:05.488747+00	2026-05-16 19:54:05.488747+00	0c294d55-2420-4614-b014-a29895605ad2	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72	owner	2026-05-16 19:54:05.744882+00
43a05c94-e385-400d-948f-a06ee14d93a4	2026-05-16 20:29:23.440129+00	2026-05-16 20:29:23.440129+00	e4dc7671-80dd-4d69-af9f-27f167ee8d6d	e098b808-8974-4bae-a6e1-de10bf6a2880	owner	2026-05-16 20:29:23.69613+00
\.


--
-- Data for Name: dashboard_users; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dashboard_users (id, created_at, updated_at, email, password_hash, display_name, totp_secret, totp_verified_at, totp_required, is_admin, is_active, timezone, notification_prefs, active_tenant_id) FROM stdin;
0c294d55-2420-4614-b014-a29895605ad2	2026-05-16 19:54:05.384304+00	2026-05-16 19:54:05.488747+00	rbac-smoke@queenswarm.love	$2b$12$GOZYED6R.YuA/IrR1DjPZeRh1tfq/lINde.EkqNJ3JmQC8vHqDfTG	RBAC Smoke	\N	\N	f	t	t	\N	{}	ab5f468c-befb-4ce5-8dc1-b81e2dda4b72
e4dc7671-80dd-4d69-af9f-27f167ee8d6d	2026-05-14 19:44:25.026822+00	2026-05-16 20:29:23.440129+00	admin@queenswarm.love	$2b$12$GdksAgGhfhA6611j9M/dSOIAj2TFKIg/oyQsW3t21XGg8EaYblFl.	Hive Queen	\N	\N	f	t	t	\N	{}	e098b808-8974-4bae-a6e1-de10bf6a2880
\.


--
-- Data for Name: dynamic_connectors; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.dynamic_connectors (id, created_at, updated_at, slug, display_name, base_url, auth_type, secrets_cipher, mcp_manifest, allowed_manager_slugs, is_active, is_builtin, builtin_kind, last_tested_at, dashboard_user_id, tenant_id) FROM stdin;
00000000-0000-4000-a000-000000000071	2026-05-14 18:14:18.137783+00	2026-05-14 18:14:18.137783+00	grokipedia	Grokipedia (built-in)	https://grokipedia.org	none	\N	{"tools": [{"name": "article_fetch", "path": "/wiki/{slug}", "method": "GET", "description": "Fetch Grokipedia article body as cleaned text (Wikipedia successor lane)."}]}	["research_intelligence"]	t	t	grokipedia	\N	\N	\N
\.


--
-- Data for Name: external_outputs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_outputs (id, created_at, dashboard_user_id, mission_id, session_id, text_report, voice_script, output_metadata, simulation_outcome, tags, tenant_id) FROM stdin;
\.


--
-- Data for Name: external_project_api_keys; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_project_api_keys (id, created_at, project_id, label, secret_hash, permissions, revoked_at, last_used_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: external_project_run_audit; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_project_run_audit (id, created_at, project_id, api_key_id, action_slug, ok, latency_ms, cost_usd, human_approval_required, human_approved, payload_excerpt, result_summary, tenant_id) FROM stdin;
\.


--
-- Data for Name: external_projects; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.external_projects (id, created_at, updated_at, slug, display_name, project_kind, owner_dashboard_user_id, settings, webhook_url, webhook_secret_hash, is_active, tenant_id) FROM stdin;
\.


--
-- Data for Name: hive_async_workflow_runs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.hive_async_workflow_runs (id, created_at, updated_at, celery_task_id, swarm_id, workflow_id, hive_task_id, requested_by_subject, lifecycle, result_snapshot, error_text, finished_at) FROM stdin;
\.


--
-- Data for Name: hive_llm_secrets; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.hive_llm_secrets (provider, ciphertext, updated_at) FROM stdin;
\.


--
-- Data for Name: hive_vector_documents; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.hive_vector_documents (id, collection_name, document, metadata, embedding, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: imitation_events; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.imitation_events (id, created_at, updated_at, copier_agent_id, copied_agent_id, recipe_id, outcome) FROM stdin;
\.


--
-- Data for Name: knowledge_items; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.knowledge_items (id, created_at, updated_at, source_url, source_type, content_text, embedding_id, neo4j_node_id, confidence_score, topic_tags, decay_factor, scraped_at, verified_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: learning_logs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.learning_logs (id, created_at, updated_at, agent_id, task_id, insight_text, applied_at, pollen_earned, tenant_id) FROM stdin;
\.


--
-- Data for Name: memory_evolution_proposals; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.memory_evolution_proposals (id, tenant_id, created_at, updated_at, proposal_kind, title, summary, payload, status, importance_score, requires_manual_approval, proposed_by_user_id, approved_by_user_id, approved_at) FROM stdin;
\.


--
-- Data for Name: operator_external_apis; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.operator_external_apis (id, created_at, updated_at, user_id, provider, label, ciphertext, base_url, is_active) FROM stdin;
\.


--
-- Data for Name: pollen_rewards; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.pollen_rewards (id, created_at, updated_at, agent_id, task_id, amount, reason, source_agent_id) FROM stdin;
\.


--
-- Data for Name: public_share_links; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.public_share_links (id, tenant_id, created_at, updated_at, resource_type, resource_id, share_token, created_by_user_id, is_active, expires_at, access_count) FROM stdin;
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.recipes (id, created_at, updated_at, name, description, topic_tags, workflow_template, success_count, fail_count, avg_pollen_earned, embedding_id, created_by_agent_id, verified_at, last_used_at, is_deprecated) FROM stdin;
\.


--
-- Data for Name: simulations; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.simulations (id, created_at, updated_at, task_id, scenario, result_data, result_type, confidence_pct, docker_container_id, duration_sec, stdout, stderr) FROM stdin;
\.


--
-- Data for Name: sub_agent_sessions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.sub_agent_sessions (id, created_at, updated_at, supervisor_session_id, role, status, runtime_mode, toolset, short_memory, spawn_order, started_at, completed_at, last_output, error_text, tenant_id) FROM stdin;
\.


--
-- Data for Name: sub_swarms; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.sub_swarms (id, created_at, updated_at, name, purpose, local_memory, queen_agent_id, last_global_sync_at, total_pollen, member_count, is_active) FROM stdin;
\.


--
-- Data for Name: supervisor_routines; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.supervisor_routines (id, created_at, updated_at, name, goal_template, schedule_kind, interval_seconds, cron_expr, runtime_mode, roles, retrieval_contract, skills, context_payload, status, is_active, created_by_subject, last_run_at, next_run_at, last_error, tenant_id) FROM stdin;
\.


--
-- Data for Name: supervisor_session_events; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.supervisor_session_events (id, created_at, updated_at, supervisor_session_id, sub_agent_session_id, event_type, level, message, payload, occurred_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: supervisor_sessions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.supervisor_sessions (id, created_at, updated_at, goal, status, runtime_mode, created_by_subject, context_summary, swarm_id, task_id, started_at, completed_at, error_text, tenant_id) FROM stdin;
\.


--
-- Data for Name: task_final_deliverables; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.task_final_deliverables (id, created_at, lineage_id, version, dashboard_user_id, source_task_id, ballroom_session_id, mission_id, slug, title, markdown_body, structured_json, tags, voice_script, chroma_embedding_id, archive_relpath) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tasks (id, created_at, updated_at, title, task_type, status, priority, payload, result, agent_id, swarm_id, workflow_id, parent_task_id, pollen_awarded, recipe_used_id, started_at, completed_at, error_msg, tenant_id) FROM stdin;
\.


--
-- Data for Name: tenant_audit_logs; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenant_audit_logs (id, created_at, updated_at, tenant_id, actor_user_id, action, target_type, target_ref, payload) FROM stdin;
\.


--
-- Data for Name: tenant_invites; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenant_invites (id, created_at, updated_at, tenant_id, email, role, invited_by_user_id, invite_token, status) FROM stdin;
\.


--
-- Data for Name: tenant_subscriptions; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenant_subscriptions (id, tenant_id, created_at, updated_at, tier, status, stripe_customer_id, stripe_subscription_id, billing_cycle_anchor, period_end_at, limits_override, feature_overrides) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.tenants (id, created_at, updated_at, slug, name, status) FROM stdin;
ab5f468c-befb-4ce5-8dc1-b81e2dda4b72	2026-05-16 19:54:05.488747+00	2026-05-16 19:54:05.488747+00	rbac-smoke-0c294d55	RBAC Smoke	active
e098b808-8974-4bae-a6e1-de10bf6a2880	2026-05-16 20:29:23.440129+00	2026-05-16 20:29:23.440129+00	hive-queen-e4dc7671	Hive Queen	active
\.


--
-- Data for Name: workflow_steps; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.workflow_steps (id, created_at, updated_at, workflow_id, step_order, description, agent_role, status, input_schema, output_schema, guardrails, evaluation_criteria, result, error_msg, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: queenswarm
--

COPY public.workflows (id, created_at, updated_at, original_task_text, decomposition_rationale, status, total_steps, completed_steps, parallelizable_groups, matching_recipe_id, estimated_duration_sec, actual_duration_sec) FROM stdin;
\.


--
-- Name: agent_configs agent_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT agent_configs_pkey PRIMARY KEY (id);


--
-- Name: agent_suggestions agent_suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: browser_automation_actions browser_automation_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_actions
    ADD CONSTRAINT browser_automation_actions_pkey PRIMARY KEY (id);


--
-- Name: browser_automation_sessions browser_automation_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: connector_vault_entries connector_vault_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT connector_vault_entries_pkey PRIMARY KEY (id);


--
-- Name: connector_vault_entries connector_vault_entries_slug_key; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT connector_vault_entries_slug_key UNIQUE (slug);


--
-- Name: cost_records cost_records_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT cost_records_pkey PRIMARY KEY (id);


--
-- Name: dashboard_api_keys dashboard_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_api_keys
    ADD CONSTRAINT dashboard_api_keys_pkey PRIMARY KEY (id);


--
-- Name: dashboard_user_tenants dashboard_user_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT dashboard_user_tenants_pkey PRIMARY KEY (id);


--
-- Name: dashboard_users dashboard_users_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT dashboard_users_pkey PRIMARY KEY (id);


--
-- Name: dynamic_connectors dynamic_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT dynamic_connectors_pkey PRIMARY KEY (id);


--
-- Name: external_outputs external_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_outputs
    ADD CONSTRAINT external_outputs_pkey PRIMARY KEY (id);


--
-- Name: external_project_api_keys external_project_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_api_keys
    ADD CONSTRAINT external_project_api_keys_pkey PRIMARY KEY (id);


--
-- Name: external_project_run_audit external_project_run_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT external_project_run_audit_pkey PRIMARY KEY (id);


--
-- Name: external_projects external_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT external_projects_pkey PRIMARY KEY (id);


--
-- Name: hive_async_workflow_runs hive_async_workflow_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT hive_async_workflow_runs_pkey PRIMARY KEY (id);


--
-- Name: hive_llm_secrets hive_llm_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_llm_secrets
    ADD CONSTRAINT hive_llm_secrets_pkey PRIMARY KEY (provider);


--
-- Name: hive_vector_documents hive_vector_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_vector_documents
    ADD CONSTRAINT hive_vector_documents_pkey PRIMARY KEY (id);


--
-- Name: imitation_events imitation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT imitation_events_pkey PRIMARY KEY (id);


--
-- Name: knowledge_items knowledge_items_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT knowledge_items_pkey PRIMARY KEY (id);


--
-- Name: learning_logs learning_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT learning_logs_pkey PRIMARY KEY (id);


--
-- Name: memory_evolution_proposals memory_evolution_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_pkey PRIMARY KEY (id);


--
-- Name: operator_external_apis operator_external_apis_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.operator_external_apis
    ADD CONSTRAINT operator_external_apis_pkey PRIMARY KEY (id);


--
-- Name: pollen_rewards pollen_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT pollen_rewards_pkey PRIMARY KEY (id);


--
-- Name: public_share_links public_share_links_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT public_share_links_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: simulations simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT simulations_pkey PRIMARY KEY (id);


--
-- Name: sub_agent_sessions sub_agent_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_agent_sessions
    ADD CONSTRAINT sub_agent_sessions_pkey PRIMARY KEY (id);


--
-- Name: sub_swarms sub_swarms_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_swarms
    ADD CONSTRAINT sub_swarms_pkey PRIMARY KEY (id);


--
-- Name: supervisor_routines supervisor_routines_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_routines
    ADD CONSTRAINT supervisor_routines_pkey PRIMARY KEY (id);


--
-- Name: supervisor_session_events supervisor_session_events_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT supervisor_session_events_pkey PRIMARY KEY (id);


--
-- Name: supervisor_sessions supervisor_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT supervisor_sessions_pkey PRIMARY KEY (id);


--
-- Name: task_final_deliverables task_final_deliverables_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT task_final_deliverables_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenant_audit_logs tenant_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: tenant_invites tenant_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT tenant_invites_pkey PRIMARY KEY (id);


--
-- Name: tenant_subscriptions tenant_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: agent_configs uq_agent_configs_agent_id; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT uq_agent_configs_agent_id UNIQUE (agent_id);


--
-- Name: agents uq_agents_name; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT uq_agents_name UNIQUE (name);


--
-- Name: dashboard_user_tenants uq_dashboard_user_tenant_membership; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT uq_dashboard_user_tenant_membership UNIQUE (dashboard_user_id, tenant_id);


--
-- Name: dashboard_users uq_dashboard_users_email; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT uq_dashboard_users_email UNIQUE (email);


--
-- Name: task_final_deliverables uq_deliverable_lineage_version; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT uq_deliverable_lineage_version UNIQUE (lineage_id, version);


--
-- Name: dynamic_connectors uq_dynamic_connectors_slug; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT uq_dynamic_connectors_slug UNIQUE (slug);


--
-- Name: external_projects uq_external_projects_slug; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT uq_external_projects_slug UNIQUE (slug);


--
-- Name: hive_async_workflow_runs uq_hive_async_workflow_runs_celery_task_id; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT uq_hive_async_workflow_runs_celery_task_id UNIQUE (celery_task_id);


--
-- Name: operator_external_apis uq_operator_external_user_provider_label; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.operator_external_apis
    ADD CONSTRAINT uq_operator_external_user_provider_label UNIQUE (user_id, provider, label);


--
-- Name: public_share_links uq_public_share_links_share_token; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT uq_public_share_links_share_token UNIQUE (share_token);


--
-- Name: recipes uq_recipes_name; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT uq_recipes_name UNIQUE (name);


--
-- Name: sub_swarms uq_sub_swarms_name; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_swarms
    ADD CONSTRAINT uq_sub_swarms_name UNIQUE (name);


--
-- Name: tenant_invites uq_tenant_invites_invite_token; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT uq_tenant_invites_invite_token UNIQUE (invite_token);


--
-- Name: tenant_subscriptions uq_tenant_subscriptions_tenant_id; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT uq_tenant_subscriptions_tenant_id UNIQUE (tenant_id);


--
-- Name: tenants uq_tenants_slug; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT uq_tenants_slug UNIQUE (slug);


--
-- Name: workflow_steps workflow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: hive_vector_documents_collection_name_idx; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX hive_vector_documents_collection_name_idx ON public.hive_vector_documents USING btree (collection_name);


--
-- Name: hive_vector_documents_embedding_hnsw_idx; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX hive_vector_documents_embedding_hnsw_idx ON public.hive_vector_documents USING hnsw (embedding public.vector_cosine_ops);


--
-- Name: ix_agent_suggestions_proposal_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_proposal_type ON public.agent_suggestions USING btree (proposal_type);


--
-- Name: ix_agent_suggestions_proposed_by_role; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_proposed_by_role ON public.agent_suggestions USING btree (proposed_by_role);


--
-- Name: ix_agent_suggestions_risk_level; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_risk_level ON public.agent_suggestions USING btree (risk_level);


--
-- Name: ix_agent_suggestions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_status ON public.agent_suggestions USING btree (status);


--
-- Name: ix_agent_suggestions_sub_agent_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_sub_agent_session_id ON public.agent_suggestions USING btree (sub_agent_session_id);


--
-- Name: ix_agent_suggestions_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_supervisor_session_id ON public.agent_suggestions USING btree (supervisor_session_id);


--
-- Name: ix_agent_suggestions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agent_suggestions_tenant_id ON public.agent_suggestions USING btree (tenant_id);


--
-- Name: ix_agents_swarm_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_agents_swarm_id ON public.agents USING btree (swarm_id);


--
-- Name: ix_browser_automation_actions_action_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_action_type ON public.browser_automation_actions USING btree (action_type);


--
-- Name: ix_browser_automation_actions_browser_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_browser_session_id ON public.browser_automation_actions USING btree (browser_session_id);


--
-- Name: ix_browser_automation_actions_occurred_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_occurred_at ON public.browser_automation_actions USING btree (occurred_at);


--
-- Name: ix_browser_automation_actions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_status ON public.browser_automation_actions USING btree (status);


--
-- Name: ix_browser_automation_actions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_actions_tenant_id ON public.browser_automation_actions USING btree (tenant_id);


--
-- Name: ix_browser_automation_sessions_mode; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_mode ON public.browser_automation_sessions USING btree (mode);


--
-- Name: ix_browser_automation_sessions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_status ON public.browser_automation_sessions USING btree (status);


--
-- Name: ix_browser_automation_sessions_sub_agent_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_sub_agent_session_id ON public.browser_automation_sessions USING btree (sub_agent_session_id);


--
-- Name: ix_browser_automation_sessions_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_supervisor_session_id ON public.browser_automation_sessions USING btree (supervisor_session_id);


--
-- Name: ix_browser_automation_sessions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_browser_automation_sessions_tenant_id ON public.browser_automation_sessions USING btree (tenant_id);


--
-- Name: ix_connector_vault_entries_credential_kind; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_credential_kind ON public.connector_vault_entries USING btree (credential_kind);


--
-- Name: ix_connector_vault_entries_dashboard_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_dashboard_user_id ON public.connector_vault_entries USING btree (dashboard_user_id);


--
-- Name: ix_connector_vault_entries_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_slug ON public.connector_vault_entries USING btree (slug);


--
-- Name: ix_connector_vault_entries_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_connector_vault_entries_tenant_id ON public.connector_vault_entries USING btree (tenant_id);


--
-- Name: ix_cost_records_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_cost_records_tenant_id ON public.cost_records USING btree (tenant_id);


--
-- Name: ix_dashboard_api_keys_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_api_keys_user_id ON public.dashboard_api_keys USING btree (user_id);


--
-- Name: ix_dashboard_user_tenants_dashboard_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_user_tenants_dashboard_user_id ON public.dashboard_user_tenants USING btree (dashboard_user_id);


--
-- Name: ix_dashboard_user_tenants_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_user_tenants_tenant_id ON public.dashboard_user_tenants USING btree (tenant_id);


--
-- Name: ix_dashboard_users_active_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_users_active_tenant_id ON public.dashboard_users USING btree (active_tenant_id);


--
-- Name: ix_dashboard_users_email; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dashboard_users_email ON public.dashboard_users USING btree (email);


--
-- Name: ix_dynamic_connectors_is_active_idx; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dynamic_connectors_is_active_idx ON public.dynamic_connectors USING btree (is_active);


--
-- Name: ix_dynamic_connectors_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dynamic_connectors_slug ON public.dynamic_connectors USING btree (slug);


--
-- Name: ix_dynamic_connectors_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_dynamic_connectors_tenant_id ON public.dynamic_connectors USING btree (tenant_id);


--
-- Name: ix_external_outputs_dashboard_user_created; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_outputs_dashboard_user_created ON public.external_outputs USING btree (dashboard_user_id, created_at);


--
-- Name: ix_external_outputs_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_outputs_tenant_id ON public.external_outputs USING btree (tenant_id);


--
-- Name: ix_external_project_api_keys_project_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_api_keys_project_id ON public.external_project_api_keys USING btree (project_id);


--
-- Name: ix_external_project_api_keys_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_api_keys_tenant_id ON public.external_project_api_keys USING btree (tenant_id);


--
-- Name: ix_external_project_run_audit_api_key_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_api_key_id ON public.external_project_run_audit USING btree (api_key_id);


--
-- Name: ix_external_project_run_audit_created_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_created_at ON public.external_project_run_audit USING btree (created_at);


--
-- Name: ix_external_project_run_audit_project_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_project_id ON public.external_project_run_audit USING btree (project_id);


--
-- Name: ix_external_project_run_audit_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_project_run_audit_tenant_id ON public.external_project_run_audit USING btree (tenant_id);


--
-- Name: ix_external_projects_owner_dashboard_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_owner_dashboard_user_id ON public.external_projects USING btree (owner_dashboard_user_id);


--
-- Name: ix_external_projects_project_kind; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_project_kind ON public.external_projects USING btree (project_kind);


--
-- Name: ix_external_projects_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_slug ON public.external_projects USING btree (slug);


--
-- Name: ix_external_projects_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_external_projects_tenant_id ON public.external_projects USING btree (tenant_id);


--
-- Name: ix_hive_async_workflow_runs_celery_task_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_hive_async_workflow_runs_celery_task_id ON public.hive_async_workflow_runs USING btree (celery_task_id);


--
-- Name: ix_knowledge_items_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_knowledge_items_tenant_id ON public.knowledge_items USING btree (tenant_id);


--
-- Name: ix_knowledge_items_topic_tags_gin; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_knowledge_items_topic_tags_gin ON public.knowledge_items USING gin (topic_tags);


--
-- Name: ix_learning_logs_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_learning_logs_tenant_id ON public.learning_logs USING btree (tenant_id);


--
-- Name: ix_memory_evolution_proposals_approved_by_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_approved_by_user_id ON public.memory_evolution_proposals USING btree (approved_by_user_id);


--
-- Name: ix_memory_evolution_proposals_proposal_kind; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_proposal_kind ON public.memory_evolution_proposals USING btree (proposal_kind);


--
-- Name: ix_memory_evolution_proposals_proposed_by_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_proposed_by_user_id ON public.memory_evolution_proposals USING btree (proposed_by_user_id);


--
-- Name: ix_memory_evolution_proposals_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_status ON public.memory_evolution_proposals USING btree (status);


--
-- Name: ix_memory_evolution_proposals_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_memory_evolution_proposals_tenant_id ON public.memory_evolution_proposals USING btree (tenant_id);


--
-- Name: ix_operator_external_apis_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_operator_external_apis_user_id ON public.operator_external_apis USING btree (user_id);


--
-- Name: ix_pollen_rewards_agent_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_pollen_rewards_agent_id ON public.pollen_rewards USING btree (agent_id);


--
-- Name: ix_public_share_links_created_by_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_created_by_user_id ON public.public_share_links USING btree (created_by_user_id);


--
-- Name: ix_public_share_links_resource_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_resource_id ON public.public_share_links USING btree (resource_id);


--
-- Name: ix_public_share_links_resource_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_resource_type ON public.public_share_links USING btree (resource_type);


--
-- Name: ix_public_share_links_share_token; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_share_token ON public.public_share_links USING btree (share_token);


--
-- Name: ix_public_share_links_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_public_share_links_tenant_id ON public.public_share_links USING btree (tenant_id);


--
-- Name: ix_recipes_topic_tags_gin; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_recipes_topic_tags_gin ON public.recipes USING gin (topic_tags);


--
-- Name: ix_sub_agent_sessions_role; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_role ON public.sub_agent_sessions USING btree (role);


--
-- Name: ix_sub_agent_sessions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_status ON public.sub_agent_sessions USING btree (status);


--
-- Name: ix_sub_agent_sessions_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_supervisor_session_id ON public.sub_agent_sessions USING btree (supervisor_session_id);


--
-- Name: ix_sub_agent_sessions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_sub_agent_sessions_tenant_id ON public.sub_agent_sessions USING btree (tenant_id);


--
-- Name: ix_supervisor_routines_created_by_subject; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_created_by_subject ON public.supervisor_routines USING btree (created_by_subject);


--
-- Name: ix_supervisor_routines_is_active; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_is_active ON public.supervisor_routines USING btree (is_active);


--
-- Name: ix_supervisor_routines_name; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_name ON public.supervisor_routines USING btree (name);


--
-- Name: ix_supervisor_routines_next_run_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_next_run_at ON public.supervisor_routines USING btree (next_run_at);


--
-- Name: ix_supervisor_routines_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_routines_tenant_id ON public.supervisor_routines USING btree (tenant_id);


--
-- Name: ix_supervisor_session_events_event_type; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_event_type ON public.supervisor_session_events USING btree (event_type);


--
-- Name: ix_supervisor_session_events_occurred_at; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_occurred_at ON public.supervisor_session_events USING btree (occurred_at);


--
-- Name: ix_supervisor_session_events_sub_agent_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_sub_agent_session_id ON public.supervisor_session_events USING btree (sub_agent_session_id);


--
-- Name: ix_supervisor_session_events_supervisor_session_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_supervisor_session_id ON public.supervisor_session_events USING btree (supervisor_session_id);


--
-- Name: ix_supervisor_session_events_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_session_events_tenant_id ON public.supervisor_session_events USING btree (tenant_id);


--
-- Name: ix_supervisor_sessions_created_by_subject; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_sessions_created_by_subject ON public.supervisor_sessions USING btree (created_by_subject);


--
-- Name: ix_supervisor_sessions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_sessions_status ON public.supervisor_sessions USING btree (status);


--
-- Name: ix_supervisor_sessions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_supervisor_sessions_tenant_id ON public.supervisor_sessions USING btree (tenant_id);


--
-- Name: ix_task_final_deliverables_lineage_created; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_task_final_deliverables_lineage_created ON public.task_final_deliverables USING btree (lineage_id, created_at);


--
-- Name: ix_task_final_deliverables_user_created; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_task_final_deliverables_user_created ON public.task_final_deliverables USING btree (dashboard_user_id, created_at);


--
-- Name: ix_tasks_swarm_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tasks_swarm_id ON public.tasks USING btree (swarm_id);


--
-- Name: ix_tasks_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tasks_tenant_id ON public.tasks USING btree (tenant_id);


--
-- Name: ix_tasks_workflow_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tasks_workflow_id ON public.tasks USING btree (workflow_id);


--
-- Name: ix_tenant_audit_logs_action; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_audit_logs_action ON public.tenant_audit_logs USING btree (action);


--
-- Name: ix_tenant_audit_logs_actor_user_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_audit_logs_actor_user_id ON public.tenant_audit_logs USING btree (actor_user_id);


--
-- Name: ix_tenant_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_audit_logs_tenant_id ON public.tenant_audit_logs USING btree (tenant_id);


--
-- Name: ix_tenant_invites_email; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_invites_email ON public.tenant_invites USING btree (email);


--
-- Name: ix_tenant_invites_invite_token; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_invites_invite_token ON public.tenant_invites USING btree (invite_token);


--
-- Name: ix_tenant_invites_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_invites_tenant_id ON public.tenant_invites USING btree (tenant_id);


--
-- Name: ix_tenant_subscriptions_status; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_status ON public.tenant_subscriptions USING btree (status);


--
-- Name: ix_tenant_subscriptions_stripe_customer_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_stripe_customer_id ON public.tenant_subscriptions USING btree (stripe_customer_id);


--
-- Name: ix_tenant_subscriptions_stripe_subscription_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_stripe_subscription_id ON public.tenant_subscriptions USING btree (stripe_subscription_id);


--
-- Name: ix_tenant_subscriptions_tenant_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_tenant_id ON public.tenant_subscriptions USING btree (tenant_id);


--
-- Name: ix_tenant_subscriptions_tier; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenant_subscriptions_tier ON public.tenant_subscriptions USING btree (tier);


--
-- Name: ix_tenants_slug; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: ix_uq_dashboard_api_keys_user_source_active; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE UNIQUE INDEX ix_uq_dashboard_api_keys_user_source_active ON public.dashboard_api_keys USING btree (user_id, source_name) WHERE ((source_name IS NOT NULL) AND (revoked_at IS NULL));


--
-- Name: ix_workflow_steps_workflow_id; Type: INDEX; Schema: public; Owner: queenswarm
--

CREATE INDEX ix_workflow_steps_workflow_id ON public.workflow_steps USING btree (workflow_id);


--
-- Name: agent_configs agent_configs_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT agent_configs_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_suggestions agent_suggestions_sub_agent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_sub_agent_session_id_fkey FOREIGN KEY (sub_agent_session_id) REFERENCES public.sub_agent_sessions(id) ON DELETE SET NULL;


--
-- Name: agent_suggestions agent_suggestions_supervisor_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_supervisor_session_id_fkey FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE SET NULL;


--
-- Name: agent_suggestions agent_suggestions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agent_suggestions
    ADD CONSTRAINT agent_suggestions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: browser_automation_actions browser_automation_actions_browser_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_actions
    ADD CONSTRAINT browser_automation_actions_browser_session_id_fkey FOREIGN KEY (browser_session_id) REFERENCES public.browser_automation_sessions(id) ON DELETE CASCADE;


--
-- Name: browser_automation_actions browser_automation_actions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_actions
    ADD CONSTRAINT browser_automation_actions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: browser_automation_sessions browser_automation_sessions_sub_agent_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_sub_agent_session_id_fkey FOREIGN KEY (sub_agent_session_id) REFERENCES public.sub_agent_sessions(id) ON DELETE SET NULL;


--
-- Name: browser_automation_sessions browser_automation_sessions_supervisor_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_supervisor_session_id_fkey FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE SET NULL;


--
-- Name: browser_automation_sessions browser_automation_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.browser_automation_sessions
    ADD CONSTRAINT browser_automation_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: connector_vault_entries connector_vault_entries_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT connector_vault_entries_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: dashboard_api_keys dashboard_api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_api_keys
    ADD CONSTRAINT dashboard_api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: dashboard_user_tenants dashboard_user_tenants_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT dashboard_user_tenants_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: dashboard_user_tenants dashboard_user_tenants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_user_tenants
    ADD CONSTRAINT dashboard_user_tenants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_outputs external_outputs_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_outputs
    ADD CONSTRAINT external_outputs_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: agents fk_agents_swarm_id_sub_swarms; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_swarm_id_sub_swarms FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id);


--
-- Name: connector_vault_entries fk_connector_vault_entries_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.connector_vault_entries
    ADD CONSTRAINT fk_connector_vault_entries_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: cost_records fk_cost_records_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT fk_cost_records_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: cost_records fk_cost_records_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT fk_cost_records_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: cost_records fk_cost_records_tenant_id_tenants; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.cost_records
    ADD CONSTRAINT fk_cost_records_tenant_id_tenants FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: dashboard_users fk_dashboard_users_active_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT fk_dashboard_users_active_tenant_id FOREIGN KEY (active_tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: dynamic_connectors fk_dynamic_connectors_dashboard_user_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT fk_dynamic_connectors_dashboard_user_id FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id);


--
-- Name: dynamic_connectors fk_dynamic_connectors_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.dynamic_connectors
    ADD CONSTRAINT fk_dynamic_connectors_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_outputs fk_external_outputs_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_outputs
    ADD CONSTRAINT fk_external_outputs_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_project_api_keys fk_external_project_api_keys_project_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_api_keys
    ADD CONSTRAINT fk_external_project_api_keys_project_id FOREIGN KEY (project_id) REFERENCES public.external_projects(id) ON DELETE CASCADE;


--
-- Name: external_project_api_keys fk_external_project_api_keys_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_api_keys
    ADD CONSTRAINT fk_external_project_api_keys_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_project_run_audit fk_external_project_run_audit_api_key_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT fk_external_project_run_audit_api_key_id FOREIGN KEY (api_key_id) REFERENCES public.external_project_api_keys(id) ON DELETE SET NULL;


--
-- Name: external_project_run_audit fk_external_project_run_audit_project_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT fk_external_project_run_audit_project_id FOREIGN KEY (project_id) REFERENCES public.external_projects(id) ON DELETE CASCADE;


--
-- Name: external_project_run_audit fk_external_project_run_audit_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_project_run_audit
    ADD CONSTRAINT fk_external_project_run_audit_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: external_projects fk_external_projects_owner_dashboard_user_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT fk_external_projects_owner_dashboard_user_id FOREIGN KEY (owner_dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: external_projects fk_external_projects_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.external_projects
    ADD CONSTRAINT fk_external_projects_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: hive_async_workflow_runs fk_hive_async_workflow_runs_hive_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT fk_hive_async_workflow_runs_hive_task_id FOREIGN KEY (hive_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: hive_async_workflow_runs fk_hive_async_workflow_runs_swarm_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT fk_hive_async_workflow_runs_swarm_id FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id) ON DELETE RESTRICT;


--
-- Name: hive_async_workflow_runs fk_hive_async_workflow_runs_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.hive_async_workflow_runs
    ADD CONSTRAINT fk_hive_async_workflow_runs_workflow_id FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE RESTRICT;


--
-- Name: imitation_events fk_imitation_copied_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT fk_imitation_copied_agent_id FOREIGN KEY (copied_agent_id) REFERENCES public.agents(id);


--
-- Name: imitation_events fk_imitation_copier_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT fk_imitation_copier_agent_id FOREIGN KEY (copier_agent_id) REFERENCES public.agents(id);


--
-- Name: imitation_events fk_imitation_recipe_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.imitation_events
    ADD CONSTRAINT fk_imitation_recipe_id FOREIGN KEY (recipe_id) REFERENCES public.recipes(id);


--
-- Name: knowledge_items fk_knowledge_items_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT fk_knowledge_items_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: learning_logs fk_learning_logs_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT fk_learning_logs_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: learning_logs fk_learning_logs_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT fk_learning_logs_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: learning_logs fk_learning_logs_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.learning_logs
    ADD CONSTRAINT fk_learning_logs_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: pollen_rewards fk_pollen_rewards_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT fk_pollen_rewards_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: pollen_rewards fk_pollen_rewards_source_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT fk_pollen_rewards_source_agent_id FOREIGN KEY (source_agent_id) REFERENCES public.agents(id);


--
-- Name: pollen_rewards fk_pollen_rewards_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.pollen_rewards
    ADD CONSTRAINT fk_pollen_rewards_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: recipes fk_recipes_created_by_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT fk_recipes_created_by_agent_id FOREIGN KEY (created_by_agent_id) REFERENCES public.agents(id);


--
-- Name: simulations fk_simulations_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT fk_simulations_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: sub_agent_sessions fk_sub_agent_sessions_supervisor_session_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_agent_sessions
    ADD CONSTRAINT fk_sub_agent_sessions_supervisor_session_id FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE CASCADE;


--
-- Name: sub_agent_sessions fk_sub_agent_sessions_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_agent_sessions
    ADD CONSTRAINT fk_sub_agent_sessions_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: sub_swarms fk_sub_swarms_queen_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.sub_swarms
    ADD CONSTRAINT fk_sub_swarms_queen_agent_id FOREIGN KEY (queen_agent_id) REFERENCES public.agents(id);


--
-- Name: supervisor_routines fk_supervisor_routines_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_routines
    ADD CONSTRAINT fk_supervisor_routines_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: supervisor_session_events fk_supervisor_session_events_sub_agent_session_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT fk_supervisor_session_events_sub_agent_session_id FOREIGN KEY (sub_agent_session_id) REFERENCES public.sub_agent_sessions(id) ON DELETE CASCADE;


--
-- Name: supervisor_session_events fk_supervisor_session_events_supervisor_session_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT fk_supervisor_session_events_supervisor_session_id FOREIGN KEY (supervisor_session_id) REFERENCES public.supervisor_sessions(id) ON DELETE CASCADE;


--
-- Name: supervisor_session_events fk_supervisor_session_events_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_session_events
    ADD CONSTRAINT fk_supervisor_session_events_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: supervisor_sessions fk_supervisor_sessions_swarm_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT fk_supervisor_sessions_swarm_id FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id) ON DELETE SET NULL;


--
-- Name: supervisor_sessions fk_supervisor_sessions_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT fk_supervisor_sessions_task_id FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: supervisor_sessions fk_supervisor_sessions_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.supervisor_sessions
    ADD CONSTRAINT fk_supervisor_sessions_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tasks fk_tasks_agent_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_agent_id FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: tasks fk_tasks_parent_task_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_parent_task_id FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id);


--
-- Name: tasks fk_tasks_recipe_used_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_recipe_used_id FOREIGN KEY (recipe_used_id) REFERENCES public.recipes(id);


--
-- Name: tasks fk_tasks_swarm_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_swarm_id FOREIGN KEY (swarm_id) REFERENCES public.sub_swarms(id);


--
-- Name: tasks fk_tasks_tenant_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_tenant_id FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tasks fk_tasks_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_workflow_id FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: workflow_steps fk_workflow_steps_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT fk_workflow_steps_workflow_id FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: workflows fk_workflows_matching_recipe_id; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_workflows_matching_recipe_id FOREIGN KEY (matching_recipe_id) REFERENCES public.recipes(id);


--
-- Name: memory_evolution_proposals memory_evolution_proposals_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: memory_evolution_proposals memory_evolution_proposals_proposed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_proposed_by_user_id_fkey FOREIGN KEY (proposed_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: memory_evolution_proposals memory_evolution_proposals_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.memory_evolution_proposals
    ADD CONSTRAINT memory_evolution_proposals_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: operator_external_apis operator_external_apis_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.operator_external_apis
    ADD CONSTRAINT operator_external_apis_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: public_share_links public_share_links_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT public_share_links_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: public_share_links public_share_links_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.public_share_links
    ADD CONSTRAINT public_share_links_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: task_final_deliverables task_final_deliverables_dashboard_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT task_final_deliverables_dashboard_user_id_fkey FOREIGN KEY (dashboard_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: task_final_deliverables task_final_deliverables_source_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.task_final_deliverables
    ADD CONSTRAINT task_final_deliverables_source_task_id_fkey FOREIGN KEY (source_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tenant_audit_logs tenant_audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.dashboard_users(id) ON DELETE SET NULL;


--
-- Name: tenant_audit_logs tenant_audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tenant_invites tenant_invites_invited_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT tenant_invites_invited_by_user_id_fkey FOREIGN KEY (invited_by_user_id) REFERENCES public.dashboard_users(id) ON DELETE CASCADE;


--
-- Name: tenant_invites tenant_invites_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_invites
    ADD CONSTRAINT tenant_invites_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tenant_subscriptions tenant_subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: queenswarm
--

ALTER TABLE ONLY public.tenant_subscriptions
    ADD CONSTRAINT tenant_subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 8xl79xJxaGuCeKAcdePQb4dbvx2bRNeOixjNxphqHQCXQdSkFkPacPMBJc8d9aE

